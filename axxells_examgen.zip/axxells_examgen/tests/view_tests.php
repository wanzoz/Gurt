<?php
session_start();
require_once("../config/db.php");

// Kontrollera att läraren är inloggad
if (!isset($_SESSION['teacher_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$teacher_id = $_SESSION['teacher_id'];
$role = $_SESSION['role'] ?? 'teacher';
$message = '';

// Kontrollera om ett meddelande finns i sessionen
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']); // Ta bort meddelandet efter visning
}

// Hämta prov baserat på användarrollen
if ($role == 'super_admin') {
    // Super admin får se alla prov
    $stmt = $pdo->query("SELECT t.*, c.name as course_name, te.name as teacher_name, t.created_by 
                        FROM tests t 
                        LEFT JOIN courses c ON t.course_id = c.course_id
                        LEFT JOIN teachers te ON t.created_by = te.teacher_id
                        ORDER BY t.created_at DESC");
    $tests = $stmt->fetchAll(PDO::FETCH_ASSOC);
} elseif ($role == 'school_admin') {
    // Skoladmin får se prov från lärare i samma skola
    $stmt = $pdo->prepare("SELECT t.*, c.name as course_name, te.name as teacher_name, t.created_by 
                          FROM tests t 
                          LEFT JOIN courses c ON t.course_id = c.course_id
                          LEFT JOIN teachers te ON t.created_by = te.teacher_id
                          WHERE te.school_id = ?
                          ORDER BY t.created_at DESC");
    $stmt->execute([$_SESSION['school_id']]);
    $tests = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    // Vanlig lärare ser endast sina egna prov
    $stmt = $pdo->prepare("SELECT t.*, c.name as course_name, t.created_by 
                          FROM tests t 
                          LEFT JOIN courses c ON t.course_id = c.course_id 
                          WHERE t.created_by = ?
                          ORDER BY t.created_at DESC");
    $stmt->execute([$teacher_id]);
    $tests = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hantera prov</title>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
        table { width: 100%; border-collapse: collapse; }
        table, th, td { border: 1px solid #ddd; padding: 8px; }
        th { background-color: #f2f2f2; }
        .btn { padding: 5px 10px; text-decoration: none; margin-right: 5px; color: white; border-radius: 3px; display: inline-block; }
        .btn-print { background-color: #17a2b8; }
        .btn-edit { background-color: #ffc107; color: #000; }
        .btn-delete { background-color: #dc3545; }
        .message { padding: 10px; margin-bottom: 15px; border-radius: 4px; }
        .success { background-color: #d4edda; color: #155724; }
        .error { background-color: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
    <h2>Hantera prov</h2>
    
    <?php if (!empty($message)): ?>
        <div class="message <?= strpos($message, 'بنجاح') !== false ? 'success' : 'error' ?>">
            <?= $message ?>
        </div>
    <?php endif; ?>
    
    <?php if (empty($tests)): ?>
        <p>Inga prov hittades.</p>
    <?php else: ?>
        <table dir="rtl">
            <thead>
                <tr>
                    <th>Provtitel</th>
                    <th>Ämne</th>
                    <?php if (in_array($role, ['school_admin', 'super_admin'])): ?>
                        <th>Lärare</th>
                    <?php endif; ?>
                    <th>Skapat datum</th>
                    <th>Åtgärder</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tests as $test): ?>
                    <tr>
                        <td><?= htmlspecialchars($test['title']) ?></td>
                        <td><?= htmlspecialchars($test['course_name'] ?? 'Ej specificerat') ?></td>
                        <?php if (in_array($role, ['school_admin', 'super_admin'])): ?>
                            <td><?= htmlspecialchars($test['teacher_name'] ?? 'Okänd') ?></td>
                        <?php endif; ?>
                        <td><?= $test['created_at'] ?? 'Okänt' ?></td>
                        <td>
                            <a href="print_test.php?test_id=<?= $test['test_id'] ?>" class="btn btn-print">Skriv ut</a>
                            <?php if ($teacher_id == $test['created_by'] || in_array($role, ['school_admin', 'super_admin'])): ?>
                                <a href="edit_test.php?test_id=<?= $test['test_id'] ?>" class="btn btn-edit">Redigera</a>
                                <a href="#" onclick="confirmDelete(<?= $test['test_id'] ?>, '<?= htmlspecialchars($test['title']) ?>')" class="btn btn-delete">Radera</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
    
    <p><a href="../dashboard/index.php">Tillbaka till kontrollpanelen</a></p>
    
    <script>
    function confirmDelete(testId, testTitle) {
        if (confirm('Är du säker på att du vill radera provet: ' + testTitle + '?')) {
            window.location.href = 'delete_test.php?test_id=' + testId;
        }
    }
    </script>
</body>
</html>