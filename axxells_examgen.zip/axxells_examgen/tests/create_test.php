<?php
// create_test.php - Fixed version
session_start();
require_once("../config/db.php");

// Aktivera felvisning för diagnostik
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['teacher_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$debug_info = [];
$message = '';

// Testa databasanslutning
try {
    $test_conn = $pdo->query("SELECT 1");
    $debug_info['db_connection'] = "Databasanslutning lyckades!";
} catch (PDOException $e) {
    $debug_info['db_connection'] = "Databasanslutning misslyckades: " . $e->getMessage();
    echo "<p style='color:red'>Databasfel: " . $e->getMessage() . "</p>";
}

// Hämta kurser
try {
    $stmt_courses = $pdo->prepare("SELECT * FROM courses WHERE school_id = ? OR school_id IS NULL");
    $stmt_courses->execute([$_SESSION['school_id'] ?? 0]);
    $courses = $stmt_courses->fetchAll(PDO::FETCH_ASSOC);
    $debug_info['courses_count'] = count($courses);
} catch (PDOException $e) {
    $debug_info['courses_error'] = $e->getMessage();
    $courses = [];
    echo "<p style='color:red'>Fel vid kursfråga: " . $e->getMessage() . "</p>";
}

// Hämta alla kategorier
try {
    $stmt_all_categories = $pdo->query("SELECT c.*, co.name as course_name FROM categories c LEFT JOIN courses co ON c.course_id = co.course_id");
    $all_categories = $stmt_all_categories->fetchAll(PDO::FETCH_ASSOC);
    $debug_info['all_categories_count'] = count($all_categories);
} catch (PDOException $e) {
    $debug_info['all_categories_error'] = $e->getMessage();
    $all_categories = [];
    echo "<p style='color:red'>Fel vid kategorifråga: " . $e->getMessage() . "</p>";
}

// Hämta frågor för diagnostik - FIXAD: Inkludera course_id direkt från kategoritabellen
try {
    $stmt_questions = $pdo->query("SELECT q.*, c.category_name, co.name as course_name, c.course_id  
                                   FROM questions q 
                                   JOIN categories c ON q.category_id = c.category_id 
                                   JOIN courses co ON c.course_id = co.course_id");
    $questions = $stmt_questions->fetchAll(PDO::FETCH_ASSOC);
    $debug_info['questions_count'] = count($questions);
} catch (PDOException $e) {
    $debug_info['questions_error'] = $e->getMessage();
    $questions = [];
    echo "<p style='color:red'>Fel vid frågefråga: " . $e->getMessage() . "</p>";
}

// Hantera formulärinlämning
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'] ?? '';
    $course_id = $_POST['course_id'] ?? '';
    $selection_mode = $_POST['selection_mode'] ?? 'manual';
    $selected_questions = [];
    
    if (empty($title) || empty($course_id)) {
        $message = "Vänligen fyll i alla obligatoriska fält.";
    } else {
        try {
            // Bestäm vilka frågor som ska inkluderas
            if ($selection_mode == 'automatic') {
                // Automatisk frågeselektering
                $num_questions = intval($_POST['num_questions'] ?? 5);
                $selected_categories = $_POST['categories'] ?? [];
                
                // Bygg SQL-frågan baserat på valda kategorier
                $sql = "SELECT q.question_id FROM questions q 
                        JOIN categories c ON q.category_id = c.category_id 
                        WHERE c.course_id = ?";
                $params = [$course_id];
                
                if (!empty($selected_categories)) {
                    $placeholders = implode(',', array_fill(0, count($selected_categories), '?'));
                    $sql .= " AND q.category_id IN ($placeholders)";
                    $params = array_merge([$course_id], $selected_categories);
                }
                
                $sql .= " ORDER BY RAND() LIMIT $num_questions";
                
                $stmt_random = $pdo->prepare($sql);
                $stmt_random->execute($params);
                $random_results = $stmt_random->fetchAll(PDO::FETCH_ASSOC);
                
                foreach ($random_results as $result) {
                    $selected_questions[] = $result['question_id'];
                }
            } else {
                // Manuell frågeselektering
                $selected_questions = $_POST['questions'] ?? [];
            }
            
            if (empty($selected_questions)) {
                $message = "Inga frågor valda eller hittades. Välj frågor manuellt eller kontrollera kategorier för automatiskt val.";
            } else {
                // Starta transaktion
                $pdo->beginTransaction();
                
                // Skapa testet
                $stmt_test = $pdo->prepare("INSERT INTO tests (title, course_id, created_by) VALUES (?, ?, ?)");
                $stmt_test->execute([$title, $course_id, $_SESSION['teacher_id']]);
                $test_id = $pdo->lastInsertId();
                
                // Lägg till frågorna
                $order = 1;
                foreach ($selected_questions as $question_id) {
                    $stmt_question = $pdo->prepare("INSERT INTO test_questions (test_id, question_id, question_order) VALUES (?, ?, ?)");
                    $stmt_question->execute([$test_id, $question_id, $order]);
                    $order++;
                }
                
                // Slutför transaktionen
                $pdo->commit();
                $message = "Provet har skapats framgångsrikt med " . count($selected_questions) . " frågor!";
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $message = "Fel vid skapande av prov: " . $e->getMessage();
            $debug_info['error'] = $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Skapa prov - Axxells Examgen</title>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
        h2 { color: #333; }
        .message { padding: 10px; margin-bottom: 15px; border-radius: 4px; }
        .success { background-color: #d4edda; color: #155724; }
        .error { background-color: #f8d7da; color: #721c24; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        select, input[type="text"], input[type="number"] { width: 100%; padding: 8px; margin-bottom: 15px; box-sizing: border-box; }
        button { background-color: #4CAF50; color: white; padding: 10px 15px; border: none; cursor: pointer; }
        button:hover { background-color: #45a049; }
        .nav-links { margin-top: 20px; }
        .nav-links a { margin-right: 15px; }
        .debug-info { background: #f8f9fa; padding: 15px; border: 1px solid #ddd; margin: 15px 0; }
        pre { white-space: pre-wrap; }
        .question-list { border: 1px solid #ddd; padding: 10px; margin-bottom: 15px; max-height: 300px; overflow-y: auto; }
        .question-item { padding: 10px; border-bottom: 1px solid #eee; }
        .question-item:last-child { border-bottom: none; }
        .selection-mode { margin-bottom: 20px; }
        .mode-option { margin-right: 15px; }
        .selection-options { border: 1px solid #eee; padding: 15px; margin-bottom: 15px; }
        .category-list { max-height: 200px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; margin-bottom: 15px; }
        .automatic-explanation { margin-bottom: 15px; padding: 10px; background-color: #f8f9fa; border-right: 4px solid #17a2b8; text-align: right; direction: rtl; }
    </style>
</head>
<body>
    <h2>Skapa nytt prov</h2>
    
    <?php if (!empty($message)): ?>
        <div class="message <?= strpos($message, 'framgångsrikt') !== false ? 'success' : 'error' ?>">
            <?= $message ?>
        </div>
    <?php endif; ?>
    
    <form method="post">
        <label for="title">Provtitel:</label>
        <input type="text" name="title" id="title" required>

        <label for="course_id">Välj kurs:</label>
        <select name="course_id" id="course_id" required onchange="loadCourseContent(this.value)">
            <option value="">-- Välj kurs --</option>
            <?php foreach ($courses as $course): ?>
                <option value="<?= $course['course_id'] ?>"><?= htmlspecialchars($course['name']) ?></option>
            <?php endforeach; ?>
        </select>
        
        <div class="selection-mode">
            <p><strong>Frågevalsmetod:</strong></p>
            <label class="mode-option">
                <input type="radio" name="selection_mode" value="manual" checked onclick="toggleSelectionMode('manual')"> 
                Välj frågor manuellt
            </label>
            <label class="mode-option">
                <input type="radio" name="selection_mode" value="automatic" onclick="toggleSelectionMode('automatic')"> 
                Välj frågor automatiskt
            </label>
        </div>
        
        <div id="manual_mode" class="selection-options">
            <h3>Välj frågor manuellt</h3>
            <div id="questions_container" class="question-list">
                <p>Välj en kurs för att ladda frågor...</p>
            </div>
        </div>
        
        <div id="automatic_mode" class="selection-options" style="display:none;">
            <h3>Välj frågor automatiskt</h3>
            <label for="num_questions">Antal slumpmässiga frågor:</label>
            <input type="number" id="num_questions" name="num_questions" min="1" max="50" value="5">
            
            <label>Välj kategorier:</label>
            <div id="categories_container" class="category-list">
                <p>Välj en kurs för att ladda kategorier...</p>
            </div>
            
            <div class="automatic-explanation">
                <p><strong>Notera om automatisk val:</strong></p>
                <ol>
                    <li>Välj de kategorier du vill välja frågor från (om inga kategorier väljs kommer frågor att väljas från alla kategorier)</li>
                    <li>Välj antal frågor du vill inkludera i provet</li>
                    <li>Klicka på "Skapa prov"-knappen och frågor kommer att väljas slumpmässigt från de valda kategorierna</li>
                </ol>
            </div>
        </div>
        
        <button type="submit">Skapa prov</button>
    </form>
    
    <div class="nav-links">
        <a href="../dashboard/index.php">Tillbaka till instrumentpanelen</a>
    </div>

    <div class="debug-info">
        <h3>Diagnostikinformation</h3>
        <pre><?= print_r($debug_info, true) ?></pre>
    </div>

    <script>
    function toggleSelectionMode(mode) {
        if (mode === 'manual') {
            document.getElementById('manual_mode').style.display = 'block';
            document.getElementById('automatic_mode').style.display = 'none';
        } else {
            document.getElementById('manual_mode').style.display = 'none';
            document.getElementById('automatic_mode').style.display = 'block';
        }
    }
    
    function loadCourseContent(courseId) {
        if (!courseId) {
            document.getElementById('questions_container').innerHTML = '<p>Vänligen välj en kurs för att ladda frågor...</p>';
            document.getElementById('categories_container').innerHTML = '<p>Vänligen välj en kurs för att ladda kategorier...</p>';
            return;
        }
        
        // Ladda frågor för vald kurs
        let questionsHTML = '<h3>Tillgängliga frågor:</h3>';
        
        <?php 
        // Gruppera frågor per kurs för enklare åtkomst i JavaScript - FIXAD: course_id nu inkluderad i frågeresultatet
        $questions_by_course = [];
        foreach ($questions as $q) {
            if (!isset($questions_by_course[$q['course_id']])) {
                $questions_by_course[$q['course_id']] = [];
            }
            $questions_by_course[$q['course_id']][] = $q;
        }
        ?>
        
        const courseQuestions = <?= json_encode($questions_by_course) ?>;
        console.log("Course ID: " + courseId);
        console.log("Questions data:", courseQuestions);
        
        if (courseQuestions[courseId] && courseQuestions[courseId].length > 0) {
            questionsHTML += '<div>';
            courseQuestions[courseId].forEach(question => {
                questionsHTML += `
                    <div class="question-item">
                        <input type="checkbox" name="questions[]" value="${question.question_id}">
                        <strong>${question.category_name || 'Okategoriserad'}</strong>
                        <div>${question.question_text}</div>
                        <small>Kurs: ${question.course_name || 'Okänd'}, Poäng: ${question.points}</small>
                    </div>
                `;
            });
            questionsHTML += '</div>';
        } else {
            questionsHTML += '<p>Inga frågor hittades för denna kurs. <a href="../questions/add_question.php">Lägg till några frågor</a> först.</p>';
        }
        
        document.getElementById('questions_container').innerHTML = questionsHTML;
        
        // Ladda kategorier för vald kurs
        let categoriesHTML = '<h3>Tillgängliga kategorier:</h3>';
        
        <?php 
        // Gruppera kategorier per kurs
        $categories_by_course = [];
        foreach ($all_categories as $cat) {
            if (!isset($categories_by_course[$cat['course_id']])) {
                $categories_by_course[$cat['course_id']] = [];
            }
            $categories_by_course[$cat['course_id']][] = $cat;
        }
        ?>
        
        const courseCategories = <?= json_encode($categories_by_course) ?>;
        if (courseCategories[courseId] && courseCategories[courseId].length > 0) {
            categoriesHTML += '<div>';
            courseCategories[courseId].forEach(category => {
                categoriesHTML += `
                    <div class="category-item">
                        <label>
                            <input type="checkbox" name="categories[]" value="${category.category_id}"> 
                            ${category.category_name}
                        </label>
                    </div>
                `;
            });
            categoriesHTML += '</div>';
            categoriesHTML += '<p><em>Om inga kategorier väljs kommer frågor att väljas från alla kategorier</em></p>';
        } else {
            categoriesHTML += '<p>Inga kategorier hittades för denna kurs.</p>';
        }
        
        document.getElementById('categories_container').innerHTML = categoriesHTML;
    }
    </script>
</body>
</html>