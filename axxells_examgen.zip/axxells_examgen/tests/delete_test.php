<?php
session_start();
require_once("../config/db.php");

// Kontrollera om läraren är inloggad
if (!isset($_SESSION['teacher_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$teacher_id = $_SESSION['teacher_id'];
$role = $_SESSION['role'] ?? 'teacher';

// Kontrollera om test-ID finns
if (!isset($_GET['test_id'])) {
    $_SESSION['message'] = "Test-ID saknas!";
    header("Location: view_tests.php");
    exit();
}

$test_id = $_GET['test_id'];

// Kontrollera provet baserat på användarroll
if ($role == 'super_admin') {
    // Superadmin kan ta bort vilket prov som helst
    $stmt_check = $pdo->prepare("SELECT * FROM tests WHERE test_id = ?");
    $stmt_check->execute([$test_id]);
} elseif ($role == 'school_admin') {
    // Skoladmin kan ta bort prov från lärare i samma skola
    $stmt_check = $pdo->prepare("
        SELECT t.* 
        FROM tests t 
        JOIN teachers te ON t.created_by = te.teacher_id 
        WHERE t.test_id = ? AND te.school_id = ?
    ");
    $stmt_check->execute([$test_id, $_SESSION['school_id']]);
} else {
    // Vanliga lärare kan bara ta bort sina egna prov
    $stmt_check = $pdo->prepare("SELECT * FROM tests WHERE test_id = ? AND created_by = ?");
    $stmt_check->execute([$test_id, $teacher_id]);
}

$test = $stmt_check->fetch(PDO::FETCH_ASSOC);

if (!$test) {
    $_SESSION['message'] = "Du har inte behörighet till detta prov eller så existerar det inte!";
    header("Location: view_tests.php");
    exit();
}

try {
    // Starta transaktionen
    $pdo->beginTransaction();
    
    // Ta först bort frågor kopplade till provet (rensa relationer)
    $stmt_delete_questions = $pdo->prepare("DELETE FROM test_questions WHERE test_id = ?");
    $stmt_delete_questions->execute([$test_id]);
    
    // Ta sedan bort själva provet
    $stmt_delete_test = $pdo->prepare("DELETE FROM tests WHERE test_id = ?");
    $stmt_delete_test->execute([$test_id]);
    
    // Avsluta transaktionen
    $pdo->commit();
    
    $_SESSION['message'] = "Provet har tagits bort framgångsrikt!";
} catch (Exception $e) {
    // Återställ ändringar vid fel
    $pdo->rollBack();
    $_SESSION['message'] = "Fel vid borttagning av provet: " . $e->getMessage();
}

// Omdirigera till sidan med provöversikt
header("Location: view_tests.php");
exit();
?>