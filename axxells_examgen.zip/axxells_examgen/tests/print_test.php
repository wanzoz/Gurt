<?php
session_start();
require_once("../config/db.php");

if (!isset($_GET['test_id']) || !isset($_SESSION['teacher_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$test_id = $_GET['test_id'];

// Get test information
$stmt = $pdo->prepare("
    SELECT t.*, c.name as course_name 
    FROM tests t 
    LEFT JOIN courses c ON t.course_id = c.course_id 
    WHERE t.test_id = ?
");
$stmt->execute([$test_id]);
$test = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$test) {
    header("Location: ../dashboard/index.php");
    exit();
}

// Get questions for this test
$stmt_questions = $pdo->prepare("
    SELECT tq.*, q.question_text, q.image_url, q.points, c.category_name 
    FROM test_questions tq 
    JOIN questions q ON tq.question_id = q.question_id 
    LEFT JOIN categories c ON q.category_id = c.category_id 
    WHERE tq.test_id = ? 
    ORDER BY tq.question_order
");
$stmt_questions->execute([$test_id]);
$questions = $stmt_questions->fetchAll(PDO::FETCH_ASSOC);

// Calculate total points before displaying
$total_points = 0;
foreach ($questions as $question) {
    $total_points += $question['points'];
}

// Get teacher information
$stmt_teacher = $pdo->prepare("SELECT name FROM teachers WHERE teacher_id = ?");
$stmt_teacher->execute([$test['created_by']]);
$teacher = $stmt_teacher->fetch(PDO::FETCH_ASSOC);

// Get school information
$stmt_school = $pdo->prepare("
    SELECT s.name as school_name 
    FROM schools s 
    JOIN teachers t ON s.school_id = t.school_id 
    WHERE t.teacher_id = ?
");
$stmt_school->execute([$test['created_by']]);
$school = $stmt_school->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Skriv ut prov: <?= htmlspecialchars($test['title']) ?> - Axxells Provgenerator</title>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: "Segoe UI", sans-serif;
            max-width: 900px;
            margin: 0 auto;
            padding: 30px;
            color: #333;
        }

        @media print {
            .no-print { display: none; }
            body { padding: 0; font-size: 12pt; }
        }

        .print-button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            margin-bottom: 20px;
            cursor: pointer;
            border-radius: 4px;
        }

        .print-button:hover {
            background-color: #0056b3;
        }

        .test-header {
            text-align: center;
            margin-bottom: 40px;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
        }

        .test-header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }

        .test-header h3, .test-header h4 {
            margin: 5px 0;
        }

        .test-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
            font-size: 14px;
            font-weight: bold;
        }

        .question {
            border: 1px solid #ccc;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            page-break-inside: avoid;
        }

        .question-header {
            display: flex;
            justify-content: space-between;
            font-weight: bold;
            background-color: #f7f7f7;
            padding: 5px 10px;
            border-bottom: 1px solid #ccc;
            margin-bottom: 10px;
        }

        .question-content {
            padding: 10px;
        }

        .question-image {
            max-width: 100%;
            height: auto;
            margin-top: 10px;
            border: 1px solid #ddd;
        }

        .answer-space {
            border-top: 1px dashed #aaa;
            margin-top: 15px;
            padding-top: 10px;
            min-height: 100px;
        }

        .test-footer {
            margin-top: 30px;
            font-weight: bold;
        }

        .nav-links a {
            text-decoration: none;
            color: #007bff;
            margin-right: 10px;
        }

        .nav-links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="no-print">
        <button class="print-button" onclick="window.print();">Skriv ut prov</button>
        <div class="nav-links">
            <a href="../dashboard/index.php">Tillbaka till översikten</a>
        </div>
    </div>

    <div class="test-header">
        <h1><?= htmlspecialchars($test['title']) ?></h1>
        <h3><?= htmlspecialchars($test['course_name'] ?? 'Ingen kurs') ?></h3>
        <?php if (isset($school['school_name'])): ?>
            <h4><?= htmlspecialchars($school['school_name']) ?></h4>
        <?php endif; ?>
    </div>

    <div class="test-info">
        <div>
            <p><strong>Lärare:</strong> <?= htmlspecialchars($teacher['name'] ?? $test['created_by']) ?></p>
            <p><strong>Datum:</strong> <?= date('Y-m-d', strtotime($test['created_at'] ?? 'now')) ?></p>
        </div>
        <div>
            <p><strong>namn:<span style="font-weight: bold;"></span></strong> ____________________________</p>
            <p><strong>ID:</strong> ____________________________</p>
            <p><strong>Totalt poäng: <span style="font-weight: bold;"><?= $total_points ?></span></strong></p>
        </div>
    </div>

    <div class="test-questions">
        <?php if (empty($questions)): ?>
            <p style="color: red;">⚠️ Inga frågor hittades för detta prov.</p>
        <?php endif; ?>
        <?php foreach ($questions as $index => $question): ?>
            <div class="question">
                <div class="question-header">
                    <div>Fråga <?= $index + 1 ?> (<?= htmlspecialchars($question['category_name'] ?? 'Okategoriserad') ?>)</div>
                    <div>Poäng: <?= $question['points'] ?></div>
                </div>
                <div class="question-content">
                    <div><?= $question['question_text'] ?></div>
                    <?php if (!empty($question['image_url'])): ?>
                        <div>
                            <img class="question-image" src="../<?= htmlspecialchars($question['image_url']) ?>" alt="Bild">
                        </div>
                    <?php endif; ?>
                    <div class="answer-space"></div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="test-footer">
        Totalt antal poäng: <?= $total_points ?>
    </div>
</body>
</html>