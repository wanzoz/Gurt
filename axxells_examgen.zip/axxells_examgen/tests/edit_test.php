<?php
session_start();
require_once("../config/db.php");

// Kontrollera om läraren är inloggad
if (!isset($_SESSION['teacher_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$teacher_id = $_SESSION['teacher_id'];
$role = $_SESSION['role'] ?? 'teacher';
$message = '';

// Kontrollera att test-ID finns
if (!isset($_GET['test_id'])) {
    $_SESSION['message'] = "Test-ID saknas!";
    header("Location: view_tests.php");
    exit();
}

$test_id = $_GET['test_id'];

// Kontrollera åtkomst baserat på användarroll
if ($role == 'super_admin') {
    // Superadmin kan redigera alla prov
    $stmt_check = $pdo->prepare("SELECT * FROM tests WHERE test_id = ?");
    $stmt_check->execute([$test_id]);
} elseif ($role == 'school_admin') {
    // Skoladmin kan redigera prov från lärare i samma skola
    $stmt_check = $pdo->prepare("
        SELECT t.* 
        FROM tests t 
        JOIN teachers te ON t.created_by = te.teacher_id 
        WHERE t.test_id = ? AND te.school_id = ?
    ");
    $stmt_check->execute([$test_id, $_SESSION['school_id']]);
} else {
    // Vanliga lärare får endast redigera sina egna prov
    $stmt_check = $pdo->prepare("SELECT * FROM tests WHERE test_id = ? AND created_by = ?");
    $stmt_check->execute([$test_id, $teacher_id]);
}

$test = $stmt_check->fetch(PDO::FETCH_ASSOC);

if (!$test) {
    $_SESSION['message'] = "Du har inte behörighet att komma åt detta prov eller så existerar det inte!";
    header("Location: view_tests.php");
    exit();
}

// Hämta frågor som är kopplade till provet
$stmt_test_questions = $pdo->prepare("
    SELECT tq.*, q.question_text, q.points, c.category_name 
    FROM test_questions tq 
    JOIN questions q ON tq.question_id = q.question_id 
    LEFT JOIN categories c ON q.category_id = c.category_id 
    WHERE tq.test_id = ? 
    ORDER BY tq.question_order
");
$stmt_test_questions->execute([$test_id]);
$test_questions = $stmt_test_questions->fetchAll(PDO::FETCH_ASSOC);

// Samla nuvarande fråge-ID:n
$current_question_ids = array_map(function($q) {
    return $q['question_id'];
}, $test_questions);

// Hämta alla kurser
$stmt_courses = $pdo->prepare("SELECT * FROM courses WHERE school_id = ? OR school_id IS NULL");
$stmt_courses->execute([$_SESSION['school_id'] ?? 0]);
$courses = $stmt_courses->fetchAll(PDO::FETCH_ASSOC);

// Hämta alla frågor för vald kurs
$stmt_all_questions = $pdo->prepare("
    SELECT q.*, c.category_name 
    FROM questions q 
    LEFT JOIN categories c ON q.category_id = c.category_id 
    LEFT JOIN courses co ON c.course_id = co.course_id 
    WHERE c.course_id = ?
");
$stmt_all_questions->execute([$test['course_id']]);
$all_questions = $stmt_all_questions->fetchAll(PDO::FETCH_ASSOC);

// Hantera uppdatering av prov
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'] ?? '';
    $course_id = $_POST['course_id'] ?? '';
    $selected_questions = $_POST['questions'] ?? [];
    
    if (!empty($title) && !empty($course_id) && !empty($selected_questions)) {
        try {
            // Starta transaktion
            $pdo->beginTransaction();
            
            // Uppdatera provinformation
            $stmt_update = $pdo->prepare("UPDATE tests SET title = ?, course_id = ? WHERE test_id = ?");
            $stmt_update->execute([$title, $course_id, $test_id]);
            
            // Ta bort befintliga frågor
            $stmt_delete = $pdo->prepare("DELETE FROM test_questions WHERE test_id = ?");
            $stmt_delete->execute([$test_id]);
            
            // Lägg till valda frågor
            $order = 1;
            foreach ($selected_questions as $question_id) {
                $stmt_question = $pdo->prepare("
                    INSERT INTO test_questions (test_id, question_id, question_order) 
                    VALUES (?, ?, ?)
                ");
                $stmt_question->execute([$test_id, $question_id, $order]);
                $order++;
            }
            
            // Bekräfta transaktion
            $pdo->commit();
            
            $_SESSION['message'] = "Provet uppdaterades framgångsrikt!";
            header("Location: view_tests.php");
            exit();
            
        } catch (Exception $e) {
            $pdo->rollBack();
            $message = "Fel vid uppdatering av provet: " . $e->getMessage();
        }
    } else {
        $message = "Vänligen fyll i alla obligatoriska fält och välj minst en fråga.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Redigera prov – Provhanteringssystem</title>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
        h2 { color: #333; }
        .message { padding: 10px; margin-bottom: 15px; border-radius: 4px; }
        .success { background-color: #d4edda; color: #155724; }
        .error { background-color: #f8d7da; color: #721c24; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        select, input[type="text"] { width: 100%; padding: 8px; margin-bottom: 15px; box-sizing: border-box; }
        button { background-color: #4CAF50; color: white; padding: 10px 15px; border: none; cursor: pointer; }
        button:hover { background-color: #45a049; }
        .question-list { border: 1px solid #ddd; padding: 10px; margin-bottom: 15px; max-height: 300px; overflow-y: auto; }
        .question-item { padding: 10px; border-bottom: 1px solid #eee; }
        .question-item:last-child { border-bottom: none; }
    </style>
</head>
<body>
    <h2>Redigera prov</h2>
    
    <?php if (!empty($message)): ?>
        <div class="message <?= strpos($message, 'framgångsrikt') !== false ? 'success' : 'error' ?>">
            <?= $message ?>
        </div>
    <?php endif; ?>
    
    <form method="post">
        <label for="title">Provtitel:</label>
        <input type="text" name="title" id="title" value="<?= htmlspecialchars($test['title']) ?>" required>

        <label for="course_id">Välj kurs:</label>
        <select name="course_id" id="course_id" required onchange="fetchQuestions(this.value)">
            <option value="">-- Välj en kurs --</option>
            <?php foreach ($courses as $course): ?>
                <option value="<?= $course['course_id'] ?>" <?= ($test['course_id'] == $course['course_id']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($course['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        
        <div id="questions_container" class="question-list">
            <?php if (empty($all_questions)): ?>
                <p>Inga frågor tillgängliga för denna kurs. <a href="../questions/add_question.php">Lägg till frågor</a> först.</p>
            <?php else: ?>
                <h3>Tillgängliga frågor</h3>
                <?php foreach ($all_questions as $question): ?>
                    <div class="question-item">
                        <input type="checkbox" name="questions[]" value="<?= $question['question_id'] ?>" 
                               <?= in_array($question['question_id'], $current_question_ids) ? 'checked' : '' ?>>
                        <strong><?= htmlspecialchars($question['category_name'] ?? 'Okategoriserad') ?></strong>
                        <div><?= $question['question_text'] ?></div>
                        <small>Poäng: <?= $question['points'] ?></small>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <button type="submit">Spara ändringar</button>
    </form>
    
    <div class="nav-links">
        <a href="view_tests.php">Tillbaka till provlistan</a>
    </div>

    <script>
    function fetchQuestions(courseId) {
        if (!courseId) {
            document.getElementById('questions_container').innerHTML = '<p>Välj en kurs för att ladda frågor...</p>';
            return;
        }

        // Här kan AJAX användas för att ladda frågor dynamiskt
        // I detta exempel laddar vi om sidan med valt kurs-ID
        window.location.href = 'edit_test.php?test_id=<?= $test_id ?>&course_id=' + courseId;
    }
    </script>
</body>
</html>