<?php
// functions.php - Hjälpfunktioner

/**
 * Kontrollera den aktuella användarens roll
 * @param array $allowed_roles En array av tillåtna roller
 * @return bool Sant om användaren har en tillåten roll
 */
function check_role($allowed_roles = ['super_admin', 'school_admin', 'teacher']) {
    if (!isset($_SESSION['teacher_id']) || !isset($_SESSION['role'])) {
        return false;
    }
    
    return in_array($_SESSION['role'], $allowed_roles);
}

/**
 * Kontrollera om användaren har åtkomst till skolan
 * @param int $school_id Skolans ID
 * @return bool Sant om användaren har åtkomst till denna skola
 */
function can_access_school($school_id) {
    if (!isset($_SESSION['teacher_id']) || !isset($_SESSION['role'])) {
        return false;
    }
    
    if ($_SESSION['role'] == 'super_admin') {
        return true; // Superadmin har åtkomst till alla skolor
    }
    
    return $_SESSION['school_id'] == $school_id;
}

/**
 * Hämta en lista över skolor som användaren har åtkomst till
 * @param PDO $pdo Databasanslutning
 * @return array En array med tillgängliga skolor
 */
function get_accessible_schools($pdo) {
    if (!isset($_SESSION['teacher_id']) || !isset($_SESSION['role'])) {
        return [];
    }
    
    if ($_SESSION['role'] == 'super_admin') {
        // Superadmin har åtkomst till alla skolor
        $stmt = $pdo->query("SELECT * FROM schools ORDER BY name");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        // Skoladministratör och lärare har bara åtkomst till sin egen skola
        $stmt = $pdo->prepare("SELECT * FROM schools WHERE school_id = ?");
        $stmt->execute([$_SESSION['school_id']]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

/**
 * Formatera datum till svenskt format
 * @param string $date Datum i formatet Y-m-d
 * @return string Datum i svenskt format
 */
function format_date_swedish($date) {
    if (empty($date)) return '';
    
    $timestamp = strtotime($date);
    $day = date('j', $timestamp);
    $month = date('n', $timestamp);
    $year = date('Y', $timestamp);
    
    $swedish_months = [
        1 => 'januari', 2 => 'februari', 3 => 'mars', 4 => 'april',
        5 => 'maj', 6 => 'juni', 7 => 'juli', 8 => 'augusti',
        9 => 'september', 10 => 'oktober', 11 => 'november', 12 => 'december'
    ];
    
    return $day . ' ' . $swedish_months[$month] . ' ' . $year;
}

/**
 * Hämta rollens namn på svenska
 * @param string $role Rollens namn på engelska
 * @return string Rollens namn på svenska
 */
function get_role_name($role) {
    $roles = [
        'teacher' => 'Lärare',
        'school_admin' => 'Skoladministratör',
        'super_admin' => 'Systemadministratör'
    ];
    
    return $roles[$role] ?? $role;
}
?>