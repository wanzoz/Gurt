<?php
require_once("../config/db.php");
require_once("../functions/functions.php");
session_start();

// Kontrollera om en session redan finns
if (isset($_SESSION['teacher_id'])) {
    header("Location: ../dashboard/index.php");
    exit();
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM teachers WHERE email = ?");
    $stmt->execute([$email]);
    $teacher = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($teacher && password_verify($password, $teacher['password_hash'])) {
        $_SESSION['teacher_id'] = $teacher['teacher_id'];
        $_SESSION['school_id'] = $teacher['school_id'];
        $_SESSION['teacher_name'] = $teacher['name'];
        $_SESSION['role'] = $teacher['role']; // Lägg till roll i sessionen
        header("Location: ../dashboard/index.php");
        exit();
    } else {
        $error = "Fel e-postadress eller lösenord.";
    }
}
?>
<!DOCTYPE html>
<html lang="sv" dir="ltr">
<head>
    <meta charset="UTF-8">
    <title>Inloggning - Axxells Examgen</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 400px; margin: 0 auto; padding: 20px; }
        h2 { color: #333; text-align: center; }
        .error { color: red; margin-bottom: 15px; text-align: center; }
        input { width: 100%; padding: 12px; margin-bottom: 10px; box-sizing: border-box; border: 1px solid #ddd; border-radius: 4px; }
        button { background-color: #4CAF50; color: white; padding: 12px 15px; border: none; cursor: pointer; width: 100%; border-radius: 4px; font-weight: bold; }
        button:hover { background-color: #45a049; }
        .container { background-color: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .logo { text-align: center; margin-bottom: 20px; }
        .logo img { max-width: 120px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 8px; font-weight: 500; }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <h1>Axxells Examgen</h1>
        </div>
        <h2>Logga in</h2>
        <?php if (!empty($error)): ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>
        <form method="post">
            <div class="form-group">
                <label for="email">E-postadress</label>
                <input type="email" name="email" id="email" placeholder="Ange din e-postadress" required>
            </div>
            <div class="form-group">
                <label for="password">Lösenord</label>
                <input type="password" name="password" id="password" placeholder="Ange ditt lösenord" required>
            </div>
            <button type="submit">Logga in</button>
        </form>
       
    </div>
</body>
</html>