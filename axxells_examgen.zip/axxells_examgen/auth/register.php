<?php
// Show all errors (for debugging - optional in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once("../config/db.php");
session_start();


if (isset($_SESSION['teacher_id'])) {
    header("Location: ../dashboard/index.php");
    exit();
}

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $school_id = intval($_POST['school_id']);

    if (!empty($name) && !empty($email) && !empty($_POST['password']) && $school_id > 0) {
        
        $check = $pdo->prepare("SELECT COUNT(*) FROM teachers WHERE email = ?");
        $check->execute([$email]);
        if ($check->fetchColumn() > 0) {
            $error = "Email already exists!";
        } else {
            try {
                $stmt = $pdo->prepare("INSERT INTO teachers (name, email, password_hash, school_id) VALUES (?, ?, ?, ?)");
                $stmt->execute([$name, $email, $password, $school_id]);
                $success = "Registration successful! Please login.";
            } catch (PDOException $e) {
                $error = "Registration failed: " . $e->getMessage();
            }
        }
    } else {
        $error = "Please fill in all fields.";
    }
}


$schools = $pdo->query("SELECT * FROM schools")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register - Axxells Examgen</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 400px; margin: 0 auto; padding: 20px; }
        h2 { color: #333; }
        .error { color: red; margin-bottom: 15px; }
        .success { color: green; margin-bottom: 15px; }
        input, select { width: 100%; padding: 8px; margin-bottom: 10px; box-sizing: border-box; }
        button { background-color: #4CAF50; color: white; padding: 10px 15px; border: none; cursor: pointer; }
        button:hover { background-color: #45a049; }
    </style>
</head>
<body>
    <h2>Register Teacher</h2>
    <?php if (!empty($error)): ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>
    <?php if (!empty($success)): ?>
        <div class="success"><?= $success ?></div>
        <p><a href="login.php">Go to Login</a></p>
    <?php else: ?>
        <form method="post">
            <input type="text" name="name" placeholder="Name" required><br>
            <input type="email" name="email" placeholder="Email" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            <select name="school_id" required>
                <option value="">-- Select School --</option>
                <?php foreach ($schools as $school): ?>
                    <option value="<?= $school['school_id'] ?>"><?= htmlspecialchars($school['name']) ?></option>
                <?php endforeach; ?>
            </select><br>
            <button type="submit">Register</button>
        </form>
        <p>Already have an account? <a href="login.php">Login here</a></p>
    <?php endif; ?>
</body>
</html>