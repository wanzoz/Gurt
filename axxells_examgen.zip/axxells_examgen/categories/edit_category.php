<?php
// edit_category.php
session_start();
require_once("../config/db.php");

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['teacher_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$message = '';
$debug_info = [];
$category = null;

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $message = "Oj! Ingen kategori har valts för redigering.";
} else {
    $category_id = $_GET['id'];

    try {
        $test_conn = $pdo->query("SELECT 1");
        $debug_info['db_connection'] = "Databasanslutning lyckades!";
    } catch (PDOException $e) {
        $debug_info['db_connection'] = "Databasanslutning misslyckades: " . $e->getMessage();
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $category_name = $_POST['category_name'];
        $category_type = $_POST['category_type'];
        $course_id = $_POST['course_id'];

        $debug_info['post_data'] = [
            'category_name' => $category_name,
            'category_type' => $category_type,
            'course_id' => $course_id
        ];

        try {
            $stmt = $pdo->prepare("UPDATE categories SET category_name = ?, category_type = ?, course_id = ? WHERE category_id = ?");
            if ($stmt->execute([$category_name, $category_type, $course_id, $category_id])) {
                header("Location: view_categories.php?updated=true");
                exit();
            } else {
                $message = "Misslyckades med att uppdatera kategorin.";
                $debug_info['update_result'] = "Misslyckades: " . print_r($stmt->errorInfo(), true);
            }
        } catch (PDOException $e) {
            $message = "Ett databasfel har inträffat.";
            $debug_info['update_error'] = $e->getMessage();
        }
    }

    try {
        $stmt = $pdo->prepare("SELECT * FROM categories WHERE category_id = ?");
        $stmt->execute([$category_id]);
        $category = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$category) {
            $message = "Kategorin finns inte!";
        }
    } catch (PDOException $e) {
        $message = "Ett fel inträffade vid hämtning av kategorin.";
        $debug_info['fetch_error'] = $e->getMessage();
    }
}

try {
    $stmt_courses = $pdo->query("SELECT * FROM courses");
    $courses = $stmt_courses->fetchAll(PDO::FETCH_ASSOC);
    $debug_info['courses_count'] = count($courses);
} catch (PDOException $e) {
    $debug_info['courses_error'] = $e->getMessage();
    $courses = [];
}
?>

<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <title>Redigera kategori - Axxells Examgen</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }
        h2 { color: #333; }
        .message { background-color: #f8f9fa; padding: 10px; margin-bottom: 15px; border-left: 5px solid #4CAF50; }
        .error-message { background-color: #f8f9fa; padding: 10px; margin-bottom: 15px; border-left: 5px solid #f44336; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select { width: 100%; padding: 8px; margin-bottom: 15px; box-sizing: border-box; }
        button { background-color: #4CAF50; color: white; padding: 10px 15px; border: none; cursor: pointer; }
        button:hover { background-color: #45a049; }
        .nav-links { margin-top: 20px; }
        .nav-links a { margin-right: 15px; }
        .debug-info { background: #f8f9fa; padding: 15px; border: 1px solid #ddd; margin: 15px 0; }
        pre { white-space: pre-wrap; }
    </style>
</head>
<body>
    <h2>Redigera kategori</h2>

    <div class="debug-info">
        <h3>Diagnostikinformation</h3>
        <p>Session-ID: <?= session_id() ?></p>
        <p>Lärar-ID: <?= $_SESSION['teacher_id'] ?? 'Inte specificerad' ?></p>
        <p>Skol-ID: <?= $_SESSION['school_id'] ?? 'Inte specificerad' ?></p>
        <pre><?= print_r($debug_info, true) ?></pre>
    </div>

    <?php if (!empty($message)): ?>
        <div class="<?= strpos($message, 'Misslyckades') !== false || strpos($message, 'fel') !== false ? 'error-message' : 'message' ?>">
            <?= $message ?>
        </div>
    <?php endif; ?>

    <?php if ($category): ?>
        <form method="POST">
            <label for="category_name">Kategorinamn:</label>
            <input type="text" name="category_name" value="<?= htmlspecialchars($category['category_name']) ?>" required>

            <label for="category_type">Kategorityp:</label>
            <input type="text" name="category_type" value="<?= htmlspecialchars($category['category_type']) ?>" required>

            <label for="course_id">Välj kurs:</label>
            <select name="course_id" required>
                <option value="">-- Välj kurs --</option>
                <?php foreach ($courses as $course): ?>
                    <option value="<?= $course['course_id'] ?>" <?= $category['course_id'] == $course['course_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($course['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button type="submit">Spara ändringar</button>
        </form>
    <?php endif; ?>

    <div class="nav-links">
        <a href="../categories/view_categories.php">Tillbaka till kategorier</a>
        <a href="../dashboard/index.php">Tillbaka till kontrollpanelen</a>
    </div>
</body>
</html>