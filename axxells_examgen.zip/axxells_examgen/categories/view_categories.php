<?php
// view_categories.php - Förbättrad version med redigering och borttagning
session_start();
require_once("../config/db.php");

if (!isset($_SESSION['teacher_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

// Aktivera felvisning för diagnostik
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Kontrollera om ett meddelande ska visas
$message = '';
if (isset($_GET['deleted']) && $_GET['deleted'] == 'true') {
    $message = "Kategorin har tagits bort!";
}
if (isset($_GET['updated']) && $_GET['updated'] == 'true') {
    $message = "Kategorin har uppdaterats!";
}
if (isset($_GET['error'])) {
    $error_codes = [
        '1' => "Kategori-ID är inte angivet.",
        '2' => "Kategorin finns inte.",
        '3' => "Misslyckades med att ta bort kategorin.",
        '4' => "Kategorin kan inte tas bort eftersom den används på annan plats.",
        '5' => "Databasfel inträffade.",
        '6' => "Ett okänt fel inträffade."
    ];
    $message = "Fel: " . ($error_codes[$_GET['error']] ?? "Okänt fel");
}

try {
    // Testa databasanslutning
    $test_conn = $pdo->query("SELECT 1");
    echo "<p style='color:green'>Databasanslutningen lyckades!</p>";

    // Hämta kategorier från databasen med kursinformation
    $stmt = $pdo->query("
        SELECT c.*, co.name as course_name 
        FROM categories c
        LEFT JOIN courses co ON c.course_id = co.course_id
        ORDER BY c.category_name
    ");

    if (!$stmt) {
        echo "<p style='color:red'>Frågan misslyckades: " . print_r($pdo->errorInfo(), true) . "</p>";
    } else {
        $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo "<p>Hittade " . count($categories) . " kategorier.</p>";
    }
} catch (PDOException $e) {
    echo "<p style='color:red'>Databasfel: " . $e->getMessage() . "</p>";
}
?>

<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visa kategorier - Axxells Provgenerator</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
        h2 { color: #333; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #f2f2f2; font-weight: bold; }
        tr:hover { background-color: #f5f5f5; }
        .nav-links { margin-top: 20px; }
        .nav-links a { margin-right: 15px; }
        .debug-info { background: #f8f9fa; padding: 15px; border: 1px solid #ddd; margin: 15px 0; }
        .message { background-color: #f8f9fa; padding: 10px; margin-bottom: 15px; border-left: 5px solid #4CAF50; }
        .error-message { background-color: #f8f9fa; padding: 10px; margin-bottom: 15px; border-left: 5px solid #f44336; }
        .action-btn { padding: 5px 10px; text-decoration: none; color: white; border-radius: 3px; display: inline-block; margin-right: 5px; }
        .edit-btn { background-color: #2196F3; }
        .delete-btn { background-color: #f44336; }
        .action-column { width: 150px; }
    </style>
</head>
<body>
    <h2>Kategorier</h2>
    
    <div class="debug-info">
        <h3>Diagnostikinformation</h3>
        <p>Sessions-ID: <?= session_id() ?></p>
        <p>Lärar-ID: <?= $_SESSION['teacher_id'] ?? 'Inte specificerat' ?></p>
        <p>Skol-ID: <?= $_SESSION['school_id'] ?? 'Inte specificerat' ?></p>
    </div>

    <?php if (!empty($message)): ?>
        <div class="<?= strpos($message, 'Fel') !== false ? 'error-message' : 'message' ?>">
            <?= $message ?>
        </div>
    <?php endif; ?>

    <?php if (empty($categories ?? [])): ?>
        <p>Inga kategorier hittades. <a href="../categories/add_category.php">Lägg till en ny kategori</a>.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Kategorinamn</th>
                    <th>Kategorityp</th>
                    <th>Kurs</th>
                    <th class="action-column">Åtgärder</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($categories as $category): ?>
                    <tr>
                        <td><?= $category['category_id'] ?></td>
                        <td><?= htmlspecialchars($category['category_name'] ?? 'Inte tillgänglig') ?></td>
                        <td><?= htmlspecialchars($category['category_type'] ?? 'Inte tillgänglig') ?></td>
                        <td><?= htmlspecialchars($category['course_name'] ?? 'Inte tillgänglig') ?></td>
                        <td>
                            <a href="edit_category.php?id=<?= $category['category_id'] ?>" class="action-btn edit-btn">Redigera</a>
                            <a href="delete_category.php?id=<?= $category['category_id'] ?>" class="action-btn delete-btn" onclick="return confirm('Är du säker på att du vill ta bort kategorin: <?= htmlspecialchars($category['category_name']) ?>?');">Ta bort</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <div class="nav-links">
        <a href="../categories/add_category.php">Lägg till ny kategori</a>
        <a href="../dashboard/index.php">Tillbaka till instrumentpanelen</a>
    </div>
</body>
</html>