<?php
// delete_category.php
session_start();
require_once("../config/db.php");

// Aktivera felvisning för diagnostik
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Logga för att se om skriptet körs
error_log("delete_category.php script is running");

if (!isset($_SESSION['teacher_id'])) {
    error_log("No teacher_id in session");
    header("Location: ../auth/login.php");
    exit();
}

// Kontrollera att det finns ett giltigt ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    error_log("Invalid category ID");
    header("Location: view_categories.php?error=1");
    exit();
}

$category_id = $_GET['id'];
error_log("Attempting to delete category ID: " . $category_id);

try {
    // Kontrollera först om kategorin finns
    $check_stmt = $pdo->prepare("SELECT category_name FROM categories WHERE category_id = ?");
    $check_stmt->execute([$category_id]);
    $category = $check_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$category) {
        error_log("Category not found: " . $category_id);
        header("Location: view_categories.php?error=2");
        exit();
    }
    
    error_log("Category found, attempting deletion: " . $category['category_name']);
    
    // Ta bort kategorin
    $delete_stmt = $pdo->prepare("DELETE FROM categories WHERE category_id = ?");
    
    if ($delete_stmt->execute([$category_id])) {
        error_log("Category deleted successfully");
        // Omdirigera tillbaka med framgångsmeddelande
        header("Location: view_categories.php?deleted=true");
        exit();
    } else {
        error_log("Failed to delete category: " . print_r($delete_stmt->errorInfo(), true));
        header("Location: view_categories.php?error=3");
        exit();
    }
} catch (PDOException $e) {
    // Om något gick fel, logga och omdirigera
    error_log("Delete category error: " . $e->getMessage());
    
    // Kan vara för att kategorin används i andra tabeller (foreign key constraint)
    if ($e->getCode() == 23000) {
        header("Location: view_categories.php?error=4");
    } else {
        header("Location: view_categories.php?error=5");
    }
    exit();
}

// Om något annat gick fel och vi hamnade här
error_log("Unexpected error in delete_category.php");
header("Location: view_categories.php?error=6");
exit();
?>