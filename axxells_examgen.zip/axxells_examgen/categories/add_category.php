<?php
// add_category.php - Förbättrad version
session_start();
require_once("../config/db.php");

// Aktivera felvisning för diagnostik
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['teacher_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$message = '';
$debug_info = [];

// Testa databasanslutning
try {
    $test_conn = $pdo->query("SELECT 1");
    $debug_info['db_connection'] = "Databasanslutning lyckades!";
} catch (PDOException $e) {
    $debug_info['db_connection'] = "Databasanslutning misslyckades: " . $e->getMessage();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $category_name = $_POST['category_name'];
    $category_type = $_POST['category_type'];
    $course_id = $_POST['course_id'];
    
    $debug_info['post_data'] = [
        'category_name' => $category_name,
        'category_type' => $category_type,
        'course_id' => $course_id
    ];
    
    try {
        $stmt = $pdo->prepare("INSERT INTO categories (category_name, category_type, course_id) VALUES (?, ?, ?)");
        if ($stmt->execute([$category_name, $category_type, $course_id])) {
            $message = "Kategorin har lagts till!";
            $debug_info['insert_result'] = "Lyckades med ID: " . $pdo->lastInsertId();
        } else {
            $message = "Fel vid tillägg av kategorin.";
            $debug_info['insert_result'] = "Misslyckades: " . print_r($stmt->errorInfo(), true);
        }
    } catch (PDOException $e) {
        $message = "Ett databasfel inträffade.";
        $debug_info['insert_error'] = $e->getMessage();
    }
}

try {
    $stmt_courses = $pdo->query("SELECT * FROM courses");
    $courses = $stmt_courses->fetchAll(PDO::FETCH_ASSOC);
    $debug_info['courses_count'] = count($courses);
} catch (PDOException $e) {
    $debug_info['courses_error'] = $e->getMessage();
    $courses = [];
}
?>

<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <title>Lägg till kategori - Axxells Examgen</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }
        h2 { color: #333; }
        .message { background-color: #f8f9fa; padding: 10px; margin-bottom: 15px; border-left: 5px solid #4CAF50; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select { width: 100%; padding: 8px; margin-bottom: 15px; box-sizing: border-box; }
        button { background-color: #4CAF50; color: white; padding: 10px 15px; border: none; cursor: pointer; }
        button:hover { background-color: #45a049; }
        .nav-links { margin-top: 20px; }
        .nav-links a { margin-right: 15px; }
        .debug-info { background: #f8f9fa; padding: 15px; border: 1px solid #ddd; margin: 15px 0; }
        pre { white-space: pre-wrap; }
    </style>
</head>
<body>
    <h2>Lägg till ny kategori</h2>
    
    <div class="debug-info">
        <h3>Diagnostikinformation</h3>
        <p>Session-ID: <?= session_id() ?></p>
        <p>Lärar-ID: <?= $_SESSION['teacher_id'] ?? 'Inte specificerad' ?></p>
        <p>Skol-ID: <?= $_SESSION['school_id'] ?? 'Inte specificerad' ?></p>
        <pre><?= print_r($debug_info, true) ?></pre>
    </div>
    
    <?php if (!empty($message)): ?>
        <div class="message"><?= $message ?></div>
    <?php endif; ?>
    
    <form method="POST">
        <label for="category_name">Kategorinamn:</label>
        <input type="text" name="category_name" required>
        
        <label for="category_type">Kategorityp:</label>
        <input type="text" name="category_type" required>
        
        <label for="course_id">Välj kurs:</label>
        <select name="course_id" required>
            <option value="">-- Välj kurs --</option>
            <?php foreach ($courses as $course): ?>
                <option value="<?= $course['course_id'] ?>"><?= htmlspecialchars($course['name']) ?></option>
            <?php endforeach; ?>
        </select>
        
        <button type="submit">Spara kategori</button>
    </form>
    
    <div class="nav-links">
        <a href="../categories/view_categories.php">Visa alla kategorier</a>
        <a href="../dashboard/index.php">Tillbaka till instrumentpanelen</a>
    </div>
</body>
</html>

<?php