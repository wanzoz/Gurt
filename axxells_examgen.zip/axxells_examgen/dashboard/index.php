<?php
session_start();
require_once("../config/db.php");
require_once("../functions/functions.php");

if (!isset($_SESSION['teacher_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$teacher_name = $_SESSION['teacher_name'] ?? 'Användare';
$role = $_SESSION['role'] ?? 'teacher';

// Initiera statistikvariabler
$questions_count = 0;
$tests_count = 0;
$teachers_count = 0;
$schools_count = 0;

try {
    // Statistik för frågor
    if ($role == 'teacher') {
        // För lärare: endast deras egna frågor - FIXED: using created_by instead of teacher_id
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM questions WHERE created_by = ?");
        $stmt->execute([$_SESSION['teacher_id']]);
        $questions_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    } elseif ($role == 'school_admin') {
        // För skoladmin: alla frågor från lärare på deras skola
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM questions q 
                              JOIN teachers t ON q.created_by = t.teacher_id 
                              WHERE t.school_id = ?");
        $stmt->execute([$_SESSION['school_id']]);
        $questions_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    } else {
        // För superadmin: alla frågor i systemet
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM questions");
        $questions_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    }

    // Statistik för prov
    if ($role == 'teacher') {
        // För lärare: endast deras egna prov - FIXED: using created_by
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM tests WHERE created_by = ?");
        $stmt->execute([$_SESSION['teacher_id']]);
        $tests_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    } elseif ($role == 'school_admin') {
        // För skoladmin: alla prov från lärare på deras skola
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM tests t 
                              JOIN teachers te ON t.created_by = te.teacher_id 
                              WHERE te.school_id = ?");
        $stmt->execute([$_SESSION['school_id']]);
        $tests_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    } else {
        // För superadmin: alla prov i systemet
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM tests");
        $tests_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    }

    // Statistik för lärare (endast för admin-roller)
    if (in_array($role, ['school_admin', 'super_admin'])) {
        if ($role == 'school_admin') {
            // För skoladmin: endast lärare på deras skola
            $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM teachers WHERE school_id = ?");
            $stmt->execute([$_SESSION['school_id']]);
            $teachers_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        } else {
            // För superadmin: alla lärare i systemet
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM teachers");
            $teachers_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            
            // Antal skolor (endast för superadmin)
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM schools");
            $schools_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        }
    }

} catch (PDOException $e) {
    // Logga fel
    error_log("Error in dashboard statistics: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="sv" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instrumentpanel - Axxells Examgen</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 1000px; margin: 0 auto; padding: 20px; }
        h2 { color: #333; }
        .welcome { background-color: #f4f4f4; padding: 15px; border-radius: 5px; margin-bottom: 20px; text-align: center; }
        .dashboard-container { display: flex; gap: 20px; }
        .sidebar { width: 250px; background-color: #f8f9fa; padding: 20px; border-radius: 5px; box-shadow: 0 0 5px rgba(0,0,0,0.1); }
        .main-content { flex: 1; background-color: #fff; padding: 20px; border-radius: 5px; box-shadow: 0 0 5px rgba(0,0,0,0.1); }

        .menu-section { margin-bottom: 20px; }
        .menu-section h3 { margin-top: 0; padding-bottom: 10px; border-bottom: 1px solid #ddd; }

        .menu-item { display: block; padding: 12px 15px; margin-bottom: 8px; color: #333; text-decoration: none; border-radius: 4px; transition: all 0.3s; }
        .menu-item:hover { background-color: #e9ecef; }
        .menu-item.active { background-color: #4CAF50; color: white; }

        .role-badge { display: inline-block; padding: 4px 8px; background-color: #4CAF50; color: white; border-radius: 4px; font-size: 0.8em; margin-right: 10px; }

        .dashboard-stats { display: flex; flex-wrap: wrap; gap: 15px; margin-bottom: 20px; }
        .stat-card { background-color: #f8f9fa; padding: 15px; border-radius: 5px; flex: 1; min-width: 200px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        .stat-card h3 { margin-top: 0; margin-bottom: 10px; }
        .stat-value { font-size: 2em; font-weight: bold; color: #4CAF50; }

        .user-menu { text-align: left; margin-bottom: 20px; }
        .logout-btn { display: inline-block; padding: 8px 12px; background-color: #dc3545; color: white; text-decoration: none; border-radius: 4px; }
        .logout-btn:hover { background-color: #c82333; }
    </style>
</head>
<body>
    <div class="welcome">
        <h2>Välkommen till Examgen-systemet</h2>
        <p><?= htmlspecialchars($teacher_name) ?> <span class="role-badge"><?= get_role_name($role) ?></span></p>
    </div>

    <div class="dashboard-container">
        <div class="sidebar">
            <div class="user-menu">
                <a href="../auth/logout.php" class="logout-btn">Logga ut</a>
            </div>

            <!-- Lärarmeny -->
            <div class="menu-section">
                <h3>Frågehantering</h3>
                <a href="../questions/add_question.php" class="menu-item">Lägg till ny fråga</a>
                <a href="../questions/view_questions.php" class="menu-item">Visa frågor</a>
            </div>

            <div class="menu-section">
                <h3>Provsadministration</h3>
                <a href="../tests/create_test.php" class="menu-item">Skapa nytt prov</a>
                <a href="../tests/view_tests.php" class="menu-item">Visa prov</a>
            </div>

            <div class="menu-section">
                <h3>Kategorier</h3>
                <a href="../categories/add_category.php" class="menu-item">Lägg till kategori</a>
                <a href="../categories/view_categories.php" class="menu-item">Visa kategorier</a>
            </div>

            <?php if (in_array($_SESSION['role'], ['school_admin', 'super_admin'])): ?>
            <!-- Skoladmin och superadmin meny -->
            <div class="menu-section">
                <h3>Lärarhantering</h3>
                <a href="../admin/manage_teachers.php" class="menu-item">Hantera lärare</a>
                <a href="../admin/add_teacher.php" class="menu-item">Lägg till lärare</a>
            </div>
            <?php endif; ?>

            <?php if ($_SESSION['role'] == 'super_admin'): ?>
            <!-- Endast för superadmin -->
            <div class="menu-section">
                <h3>Skolhantering</h3>
                <a href="../admin/manage_schools.php" class="menu-item">Hantera skolor</a>
                <a href="../admin/add_school.php" class="menu-item">Lägg till skola</a>
            </div>
            <?php endif; ?>
        </div>

        <div class="main-content">
            <h2>Huvudpanel</h2>

            <div class="dashboard-stats">
                <!-- Statistik för alla användare -->
                <div class="stat-card">
                    <h3>Frågor</h3>
                    <div class="stat-value"><?= $questions_count ?></div>
                </div>

                <div class="stat-card">
                    <h3>Prov</h3>
                    <div class="stat-value"><?= $tests_count ?></div>
                </div>

                <?php if (in_array($_SESSION['role'], ['school_admin', 'super_admin'])): ?>
                <!-- Statistik för administratörer -->
                <div class="stat-card">
                    <h3>Lärare</h3>
                    <div class="stat-value"><?= $teachers_count ?></div>
                </div>
                <?php endif; ?>
                
                <?php if ($_SESSION['role'] == 'super_admin'): ?>
                <!-- Statistik endast för superadmin -->
                <div class="stat-card">
                    <h3>Skolor</h3>
                    <div class="stat-value"><?= $schools_count ?></div>
                </div>
                <?php endif; ?>
            </div>

            <div class="recent-activity">
                <h3>Senaste aktivitet</h3>
                <p>Du kan börja skapa nya frågor eller prov från menyn till vänster.</p>
                
                <?php if (in_array($_SESSION['role'], ['school_admin', 'super_admin'])): ?>
                <p>Som <?= get_role_name($role) ?> kan du se statistik för alla användare under din behörighetsnivå.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>