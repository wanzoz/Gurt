<?php
session_start();
require_once("../config/db.php");
require_once("../functions/functions.php");

// Kontrollera att användaren är en skoladministratör eller superadmin
if (!check_role(['school_admin', 'super_admin'])) {
    header("Location: ../auth/login.php");
    exit();
}

$message = '';
$error = '';

// Ta bort lärare
if (isset($_GET['delete_id']) && is_numeric($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $can_delete = false;
    
    // Kontrollera om användaren har rätt att ta bort denna lärare
    if ($_SESSION['role'] == 'super_admin') {
        $can_delete = true; // Superadmin kan ta bort alla lärare
    } else {
        // Kontrollera om läraren tillhör samma skola som administratören
        $check_stmt = $pdo->prepare("SELECT school_id FROM teachers WHERE teacher_id = ?");
        $check_stmt->execute([$delete_id]);
        $teacher_data = $check_stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($teacher_data && $teacher_data['school_id'] == $_SESSION['school_id']) {
            $can_delete = true;
        }
    }
    
    if ($can_delete) {
        try {
            $stmt = $pdo->prepare("DELETE FROM teachers WHERE teacher_id = ?");
            if ($stmt->execute([$delete_id])) {
                $message = "Läraren har tagits bort";
            } else {
                $error = "Ett fel inträffade vid borttagning av läraren";
            }
        } catch (PDOException $e) {
            // Om en främmande nyckel hindrar borttagning
            $error = "Den här läraren kan inte tas bort eftersom den är kopplad till andra data i systemet";
        }
    } else {
        $error = "Du har inte behörighet att ta bort denna lärare";
    }
}

// Hämta lärare
$params = [];
$sql_where = '';

if ($_SESSION['role'] == 'school_admin') {
    // Skoladministratör ser endast sina egna lärare
    $sql_where = "WHERE t.school_id = ?";
    $params[] = $_SESSION['school_id'];
}
// För superadmin behövs ingen WHERE-klausul, de ser alla lärare

// Hantera sökning om det finns
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search_term = "%" . $_GET['search'] . "%";
    if (empty($sql_where)) {
        $sql_where = "WHERE (t.name LIKE ? OR t.email LIKE ? OR s.name LIKE ?)";
    } else {
        $sql_where .= " AND (t.name LIKE ? OR t.email LIKE ? OR s.name LIKE ?)";
    }
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

$sql = "SELECT t.*, s.name as school_name 
        FROM teachers t 
        LEFT JOIN schools s ON t.school_id = s.school_id 
        $sql_where 
        ORDER BY t.name";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="sv" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lärarhantering - Axxells Examgen</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; max-width: 1000px; margin: 0 auto; padding: 20px; }
        h2 { color: #333; }
        .message { padding: 10px; margin-bottom: 15px; border-radius: 4px; }
        .success { background-color: #d4edda; color: #155724; }
        .error { background-color: #f8d7da; color: #721c24; }
        
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px; text-align: center; border-bottom: 1px solid #ddd; }
        th { background-color: #f2f2f2; font-weight: bold; }
        tr:hover { background-color: #f5f5f5; }
        
        .btn { display: inline-block; padding: 8px 15px; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; margin-right: 5px; }
        .btn-primary { background-color: #4CAF50; color: white; }
        .btn-primary:hover { background-color: #45a049; }
        .btn-secondary { background-color: #6c757d; color: white; }
        .btn-secondary:hover { background-color: #5a6268; }
        .btn-danger { background-color: #dc3545; color: white; }
        .btn-danger:hover { background-color: #c82333; }
        
        .action-buttons { white-space: nowrap; }
        
        .header-actions { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .search-form { display: flex; gap: 10px; }
        .search-form input { padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
        
        .role-badge { display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 0.8em; }
        .role-teacher { background-color: #17a2b8; color: white; }
        .role-school_admin { background-color: #fd7e14; color: white; }
        .role-super_admin { background-color: #6f42c1; color: white; }
    </style>
</head>
<body>
    <h2>Lärarhantering</h2>
    
    <?php if (!empty($message)): ?>
        <div class="message success"><?= $message ?></div>
    <?php endif; ?>
    
    <?php if (!empty($error)): ?>
        <div class="message error"><?= $error ?></div>
    <?php endif; ?>
    
    <div class="header-actions">
        <a href="../admin/add_teacher.php" class="btn btn-primary">Lägg till ny lärare</a>
        
        <form method="get" class="search-form">
            <input type="text" name="search" placeholder="Sök efter lärare..." value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
            <button type="submit" class="btn btn-secondary">Sök</button>
        </form>
    </div>
    
    <?php if (empty($teachers)): ?>
        <p>Det finns inga lärare att visa</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Namn</th>
                    <th>E-post</th>
                    <th>Skola</th>
                    <th>Roll</th>
                    <th>Åtgärder</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($teachers as $teacher): ?>
                    <tr>
                        <td><?= htmlspecialchars($teacher['name']) ?></td>
                        <td><?= htmlspecialchars($teacher['email']) ?></td>
                        <td><?= htmlspecialchars($teacher['school_name'] ?? 'Inte angivet') ?></td>
                        <td>
                            <span class="role-badge role-<?= $teacher['role'] ?>">
                                <?= get_role_name($teacher['role']) ?>
                            </span>
                        </td>
                        <td class="action-buttons">
                            <a href="../admin/edit_teacher.php?id=<?= $teacher['teacher_id'] ?>" class="btn btn-secondary">Redigera</a>
                            <a href="?delete_id=<?= $teacher['teacher_id'] ?>" class="btn btn-danger" onclick="return confirm('Är du säker på att du vill ta bort denna lärare?')">Ta bort</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
    
    <div style="margin-top: 20px;">
        <a href="../dashboard/index.php" class="btn btn-secondary">Tillbaka till kontrollpanelen</a>
    </div>
</body>
</html>