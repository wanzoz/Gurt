<?php
session_start();
require_once("../config/db.php");
require_once("../functions/functions.php");

if (!check_role(['school_admin', 'super_admin'])) {
    header("Location: ../auth/login.php");
    exit();
}

$message = '';
$error = '';
$schools = get_accessible_schools($pdo);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $school_id = $_POST['school_id'];

    // Validera data
    if (empty($name) || empty($email) || empty($_POST['password'])) {
        $error = "Alla fält är obligatoriska!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Ogiltig e-postadress!";
    } else {
        try {
            // Kontrollera om e-postadressen redan finns
            $stmt = $pdo->prepare("SELECT * FROM teachers WHERE email = ?");
            $stmt->execute([$email]);
            
            if ($stmt->rowCount() > 0) {
                $error = "E-postadressen är redan registrerad!";
            } else {
                // Lägg till ny lärare
                $stmt = $pdo->prepare("INSERT INTO teachers (name, email, password_hash, role, school_id) 
                                     VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$name, $email, $password, $role, $school_id]);
                
                $message = "Läraren har lagts till!";
                header("Location: manage_teachers.php? success=1");
                exit();
            }
        } catch (PDOException $e) {
            $error = "Databasfel: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="sv" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lägg till ny lärare</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input, select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        .message {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }
        .success {
            background-color: #dff0d8;
            color: #3c763d;
        }
        .error {
            background-color: #f2dede;
            color: #a94442;
        }
        .btn-secondary { 
            color: blue;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin: 500px;
    
        }
         


    </style>
</head>
<body>
    <div class="container">
        <h1>Lägg till ny lärare</h1>
        
        <?php if (!empty($error)): ?>
            <div class="message error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <?php if (!empty($message)): ?>
            <div class="message success"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="name">Fullständigt namn:</label>
                <input type="text" id="name" name="name" required>
            </div>
            
            <div class="form-group">
                <label for="email">E-postadress:</label>
                <input type="email" id="email" name="email" required>
            </div>
            
            <div class="form-group">
                <label for="password">Lösenord:</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <div class="form-group">
                <label for="role">Roll:</label>
                <select id="role" name="role" required>
                    <option value="teacher">Lärare</option>
                    <?php if (check_role(['super_admin'])): ?>
                        <option value="school_admin">Skoladministratör</option>
                    <?php endif; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="school_id">Skola:</label>
                <select id="school_id" name="school_id" required>
                    <option value="">-- Välj skola --</option>
                    <?php foreach ($schools as $school): ?>
                        <option value="<?= $school['school_id'] ?>">
                            <?= htmlspecialchars($school['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <button type="submit">Lägg till lärare</button>
        </form>
    </div>
    <div style="margin-top: 20px;">
        <a href="../dashboard/index.php" class="btn btn-secondary">Tillbaka till kontrollpanelen</a>
    </div>
</body>
</html>
