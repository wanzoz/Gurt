<?php
session_start();
require_once("../config/db.php");
require_once("../functions/functions.php");

// Kontrollera behörighet
if (!check_role(['school_admin', 'super_admin'])) {
    header("Location: ../auth/login.php");
    exit();
}

$error = '';
$message = '';

// Hämta skolor för dropdown
$schools = [];
// Nu kan alla administratörer se skolor, men valen varierar beroende på åtkomstnivå.
$stmt = $pdo->query("SELECT * FROM schools ORDER BY name");
$schools = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Hämta lärarens data
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: manage_teachers.php");
    exit();
}

$teacher_id = $_GET['id'];

// Se till att läraren finns och att användaren har behörighet att redigera den.
$stmt = $pdo->prepare("SELECT t.*, s.name as school_name 
                      FROM teachers t 
                      LEFT JOIN schools s ON t.school_id = s.school_id 
                      WHERE t.teacher_id = ?");
$stmt->execute([$teacher_id]);
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$teacher) {
    $error = "Läraren hittades inte.";
} elseif ($_SESSION['role'] == 'school_admin' && $teacher['school_id'] != $_SESSION['school_id']) {
    $error = "Du har inte behörighet att redigera denna lärare.";
}

// VIKTIGT: Kontrollera om en skoladministratör försöker ändra en super_admin
if ($_SESSION['role'] == 'school_admin' && $teacher['role'] == 'super_admin') {
    $error = "Du har inte behörighet att redigera super_admin användare.";
}

// Hantera formulär endast om det inte finns något fel och formuläret har skickats
if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($error)) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = !empty($_POST['password']) ? password_hash($_POST['password'], PASSWORD_DEFAULT) : null;

    // Om det ursprungliga värdet är super_admin och användaren inte är super_admin, behåll super_admin
    if ($teacher['role'] == 'super_admin' && $_SESSION['role'] != 'super_admin') {
        $role = 'super_admin'; // Behåll super_admin roll oavsett vad som skickades i formuläret
    } else {
        $role = $_POST['role'];
        
        // Förhindra promotion till super_admin om man inte själv är super_admin
        if ($_SESSION['role'] != 'super_admin' && $role == 'super_admin') {
            $role = $teacher['role']; // Återställ till tidigare roll
        }
    }

    $school_id = $_POST['school_id'];
    
    // Om man är skoladmin, kontrollera att man håller sig till sin skola
    if ($_SESSION['role'] == 'school_admin' && $school_id != $_SESSION['school_id']) {
        $school_id = $_SESSION['school_id']; // Återställ till användarens skola
    }

    if (empty($name) || empty($email)) {
        $error = "Alla fält måste fyllas i.";
    } else {
        // Uppdatera med eller utan lösenord
        if ($password) {
            $update_stmt = $pdo->prepare("UPDATE teachers SET name = ?, email = ?, role = ?, school_id = ?, password_hash = ? WHERE teacher_id = ?");
            $params = [$name, $email, $role, $school_id, $password, $teacher_id];
        } else {
            $update_stmt = $pdo->prepare("UPDATE teachers SET name = ?, email = ?, role = ?, school_id = ? WHERE teacher_id = ?");
            $params = [$name, $email, $role, $school_id, $teacher_id];
        }

        if ($update_stmt->execute($params)) {
            $message = "Läraren har uppdaterats.";
            // Uppdatera lärardata direkt
            $teacher['name'] = $name;
            $teacher['email'] = $email;
            $teacher['role'] = $role;
            $teacher['school_id'] = $school_id;
            
            // Hämta skolnamnet för visning
            $school_stmt = $pdo->prepare("SELECT name FROM schools WHERE school_id = ?");
            $school_stmt->execute([$school_id]);
            $school_data = $school_stmt->fetch(PDO::FETCH_ASSOC);
            $teacher['school_name'] = $school_data['name'] ?? '';
        } else {
            $error = "Något gick fel vid uppdateringen.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <title>Redigera Lärare - Axxells Examgen</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 700px; margin: 30px auto; padding: 20px; }
        h2 { color: #333; }
        .message { padding: 10px; margin-bottom: 15px; border-radius: 4px; }
        .success { background-color: #d4edda; color: #155724; }
        .error { background-color: #f8d7da; color: #721c24; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; }
        input, select { width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
        .btn { padding: 10px 20px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer; }
        .btn:hover { background-color: #45a049; }
        .back-link { display: inline-block; margin-top: 15px; }
        .password-note { font-size: 0.9em; color: #666; margin-top: 5px; }
    </style>
</head>
<body>
    <h2>Redigera Lärare</h2>

    <?php if (!empty($message)): ?>
        <div class="message success"><?= $message ?></div>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
        <div class="message error"><?= $error ?></div>
    <?php endif; ?>
    
    <?php if (empty($error) || $error == "Alla fält måste fyllas i." || $error == "Något gick fel vid uppdateringen."): ?>
        <form method="post">
            <div class="form-group">
                <label for="name">Namn:</label>
                <input type="text" name="name" id="name" value="<?= htmlspecialchars($teacher['name']) ?>" required>
            </div>

            <div class="form-group">
                <label for="email">E-post:</label>
                <input type="email" name="email" id="email" value="<?= htmlspecialchars($teacher['email']) ?>" required>
            </div>

            <div class="form-group">
                <label for="password">Nytt lösenord (lämna tomt för att behålla nuvarande):</label>
                <input type="password" name="password" id="password">
                <div class="password-note">Endast administratörer kan ändra lösenord</div>
            </div>

            <div class="form-group">
                <label for="role">Roll:</label>
                <select name="role" id="role" required <?= ($_SESSION['role'] != 'super_admin' && $teacher['role'] == 'super_admin') ? 'disabled' : '' ?>>
                    <option value="teacher" <?= $teacher['role'] == 'teacher' ? 'selected' : '' ?>>Lärare</option>
                    <option value="school_admin" <?= $teacher['role'] == 'school_admin' ? 'selected' : '' ?>>Skoladministratör</option>
                    <?php if ($_SESSION['role'] == 'super_admin'): ?>
                        <option value="super_admin" <?= $teacher['role'] == 'super_admin' ? 'selected' : '' ?>>Superadmin</option>
                    <?php endif; ?>
                </select>
                <?php if ($_SESSION['role'] != 'super_admin' && $teacher['role'] == 'super_admin'): ?>
                    <input type="hidden" name="role" value="super_admin">
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="school_id">Skola:</label>
                <select name="school_id" id="school_id" required <?= $_SESSION['role'] == 'school_admin' || ($_SESSION['role'] != 'super_admin' && $teacher['role'] == 'super_admin') ? 'disabled' : '' ?>>
                    <option value="">-- Välj skola --</option>
                    <?php foreach ($schools as $school): ?>
                        <?php 
                        // Skoladministratörer ser bara sin egen skola
                        if ($_SESSION['role'] == 'school_admin' && $school['school_id'] != $_SESSION['school_id']) {
                            continue;
                        }
                        ?>
                        <option value="<?= $school['school_id'] ?>" <?= $teacher['school_id'] == $school['school_id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($school['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if ($_SESSION['role'] == 'school_admin'): ?>
                    <input type="hidden" name="school_id" value="<?= htmlspecialchars($_SESSION['school_id']) ?>">
                <?php elseif ($_SESSION['role'] != 'super_admin' && $teacher['role'] == 'super_admin'): ?>
                    <input type="hidden" name="school_id" value="<?= htmlspecialchars($teacher['school_id']) ?>">
                <?php endif; ?>
            </div>

            <button type="submit" class="btn" <?= ($_SESSION['role'] != 'super_admin' && $teacher['role'] == 'super_admin') ? 'disabled' : '' ?>>Spara ändringar</button>
        </form>
    <?php endif; ?>

    <a href="manage_teachers.php" class="back-link">← Tillbaka till lärarhantering</a>
</body>
</html>