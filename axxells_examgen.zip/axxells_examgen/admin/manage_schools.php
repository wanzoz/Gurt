<?php
session_start();
require_once("../config/db.php");
require_once("../functions/functions.php");

// Kontrollera att användaren är en systemadministratör (superadmin)
if (!check_role(['super_admin'])) {
    header("Location: ../auth/login.php");
    exit();
}

$message = '';
$error = '';

// Ta bort en skola
if (isset($_GET['delete_id']) && is_numeric($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    
    try {
        // Kontrollera om skolan har lärare kopplade till sig
        $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM teachers WHERE school_id = ?");
        $check_stmt->execute([$delete_id]);
        $has_teachers = $check_stmt->fetchColumn() > 0;
        
        if ($has_teachers) {
            $error = "Skolan kan inte tas bort eftersom den har kopplade lärare. Flytta eller ta bort lärarna först";
        } else {
            $stmt = $pdo->prepare("DELETE FROM schools WHERE school_id = ?");
            if ($stmt->execute([$delete_id])) {
                $message = "Skolan har tagits bort.";
            } else {
                $error = "Ett fel inträffade vid borttagning av skolan.";
            }
        }
    } catch (PDOException $e) {
        $error = "Skolan kan inte tas bort eftersom den är kopplad till andra data i systemet";
    }
}

// Sök efter skolor
$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';
$params = [];
$sql_where = '';

if (!empty($search_term)) {
    $sql_where = "WHERE name LIKE ? OR address LIKE ? OR email LIKE ?";
    $search_param = "%" . $search_term . "%";
    $params = [$search_param, $search_param, $search_param];
}

$sql = "SELECT * FROM schools $sql_where ORDER BY name";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$schools = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Hämta antal lärare för varje skola
$school_stats = [];
foreach ($schools as $school) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM teachers WHERE school_id = ?");
    $stmt->execute([$school['school_id']]);
    $school_stats[$school['school_id']]['teachers_count'] = $stmt->fetchColumn();
}
?>

<!DOCTYPE html>
<html lang="sv" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Skolhantering - Provsystem</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
            direction: rtl;
        }
        h2 {
            color: #333;
            text-align: center;
            margin-bottom: 30px;
        }
        .message {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
            text-align: center;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        tr:hover {
            background-color: #f5f5f5;
        }

        .btn {
            display: inline-block;
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            margin-right: 5px;
        }
        .btn-primary {
            background-color: #4CAF50;
            color: white;
        }
        .btn-primary:hover {
            background-color: #45a049;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .btn-danger {
            background-color: #dc3545;
            color: white;
        }
        .btn-danger:hover {
            background-color: #c82333;
        }

        .action-buttons {
            white-space: nowrap;
        }

        .header-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .search-form {
            display: flex;
            gap: 10px;
        }
        .search-form input {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 300px;
        }

        .empty-message {
            text-align: center;
            padding: 20px;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <h2>Skolhantering</h2>

    <?php if (!empty($message)): ?>
        <div class="message success"><?= $message ?></div>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
        <div class="message error"><?= $error ?></div>
    <?php endif; ?>

    <div class="header-actions">
        <a href="add_school.php" class="btn btn-primary">Lägg till ny skola</a>

        <form method="get" class="search-form">
            <input type="text" name="search" placeholder="Sök efter skola..." value="<?= htmlspecialchars($search_term) ?>">
            <button type="submit" class="btn btn-secondary">Sök</button>
            <?php if (!empty($search_term)): ?>
                <a href="manage_schools.php" class="btn btn-secondary">Rensa sökning</a>
            <?php endif; ?>
        </form>
    </div>

    <?php if (empty($schools)): ?>
        <div class="empty-message">
            <p>Inga skolor att visa.</p>
            <?php if (!empty($search_term)): ?>
                <p>Inga resultat matchar din sökning. Prova med andra sökord</p>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Skolnamn</th>
                    <th>Adress</th>
                    <th>E-post</th>
                    <th>Telefonnummer</th>
                    <th>Antal lärare</th>
                    <th>Åtgärder</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; foreach ($schools as $school): ?>
                    <tr>
                        <td><?= $i++ ?></td>
                        <td><?= htmlspecialchars($school['name']) ?></td>
                        <td><?= htmlspecialchars($school['address'] ?? 'Ej angiven') ?></td>
                        <td><?= htmlspecialchars($school['email'] ?? 'Ej angiven') ?></td>
                        <td><?= htmlspecialchars($school['phone'] ?? 'Ej angiven') ?></td>
                        <td><?= $school_stats[$school['school_id']]['teachers_count'] ?? 0 ?> </td>
                        <td class="action-buttons">
                            <a href="edit_school.php?id=<?= $school['school_id'] ?>" class="btn btn-secondary">Redigera</a>
                            <a href="?delete_id=<?= $school['school_id'] ?>" class="btn btn-danger"
                               onclick="return confirm('Är du säker på att du vill ta bort denna skola?')">Ta bort</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <div style="margin-top: 20px;">
        <a href="../dashboard/index.php" class="btn btn-secondary">Tillbaka till kontrollpanelen</a>
    </div>
</body>
</html>
