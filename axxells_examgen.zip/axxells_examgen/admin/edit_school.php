<?php
session_start();
require_once("../config/db.php");
require_once("../functions/functions.php");

// Kontrollera att användaren är superadministratör
if (!check_role(['super_admin'])) {
    header("Location: ../auth/login.php");
    exit();
}

$message = '';
$error = '';

// Kontrollera skol-ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: manage_schools.php");
    exit();
}

$school_id = $_GET['id'];

// Hämta skoldata
$stmt = $pdo->prepare("SELECT * FROM schools WHERE school_id = ?");
$stmt->execute([$school_id]);
$school = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$school) {
    header("Location: manage_schools.php");
    exit();
}

// Bearbeta formulär
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $address = trim($_POST['address']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $description = trim($_POST['description']);

    // Validering
    if (empty($name)) {
        $error = "Skolans namn är obligatoriskt!";
    } elseif (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Ogiltig e-postadress!";
    } else {
        try {
            // Kontrollera om skolnamnet redan finns för en annan skola
            $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM schools WHERE name = ? AND school_id != ?");
            $check_stmt->execute([$name, $school_id]);
            
            if ($check_stmt->fetchColumn() > 0) {
                $error = "Skolans namn finns redan för en annan skola!";
            } else {
                // Uppdatera skolans data
                $stmt = $pdo->prepare("UPDATE schools SET name = ?, address = ?, email = ?, phone = ?, description = ? WHERE school_id = ?");
                $stmt->execute([$name, $address, $email, $phone, $description, $school_id]);
                
                $message = "Skolans information har uppdaterats!";
                
                // Uppdatera visad data
                $school['name'] = $name;
                $school['address'] = $address;
                $school['email'] = $email;
                $school['phone'] = $phone;
                $school['description'] = $description;
            }
        } catch (PDOException $e) {
            $error = "Databasfel: " . $e->getMessage();
        }
    }
}

// Hämta skolstatistik
$teacher_count = $pdo->prepare("SELECT COUNT(*) FROM teachers WHERE school_id = ?");
$teacher_count->execute([$school_id]);
$teachers_count = $teacher_count->fetchColumn();
?>

<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redigera skola - Provsystem</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        h2 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }
        .container {
            background-color: #fff;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input, textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-family: inherit;
            font-size: 14px;
        }
        textarea {
            height: 100px;
            resize: vertical;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
        }
        button:hover {
            background-color: #45a049;
        }
        .message {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
            text-align: center;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 4px;
            margin-top: 15px;
            display: inline-block;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 15px;
        }
        .school-stats {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .school-stats p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Redigera skola</h2>
        
        <div class="school-stats">
            <p><strong>Statistik för skolan:</strong></p>
            <p>Antal lärare: <?= $teachers_count ?></p>
        </div>
        
        <?php if (!empty($message)): ?>
            <div class="message success"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        
        <?php if (!empty($error)): ?>
            <div class="message error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="name">Skolans namn: <span style="color: red;">*</span></label>
                <input type="text" id="name" name="name" value="<?= htmlspecialchars($school['name']) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="address">Adress:</label>
                <input type="text" id="address" name="address" value="<?= htmlspecialchars($school['address'] ?? '') ?>">
            </div>
            
            <div class="form-group">
                <label for="email">E-postadress:</label>
                <input type="email" id="email" name="email" value="<?= htmlspecialchars($school['email'] ?? '') ?>">
            </div>
            
            <div class="form-group">
                <label for="phone">Telefonnummer:</label>
                <input type="text" id="phone" name="phone" value="<?= htmlspecialchars($school['phone'] ?? '') ?>">
            </div>
            
            <div class="form-group">
                <label for="description">Skolbeskrivning:</label>
                <textarea id="description" name="description"><?= htmlspecialchars($school['description'] ?? '') ?></textarea>
            </div>
            
            <div class="buttons">
                <button type="submit">Spara ändringar</button>
                <a href="manage_schools.php" class="btn-secondary">Tillbaka till skolöversikten</a>
            </div>
        </form>
    </div>
</body>
</html>
