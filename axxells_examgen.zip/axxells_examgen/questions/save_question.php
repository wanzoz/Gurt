<?php
session_start();
require_once("../config/db.php");

if (!isset($_SESSION['teacher_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    header("Location: add_question.php?error=invalid_request");
    exit();
}

// Validate required fields
if (empty($_POST['category_id']) || empty($_POST['question_text'])) {
    header("Location: add_question.php?error=missing_fields");
    exit();
}

$category_id = $_POST['category_id'];
$question_text = $_POST['question_text'];
$points = $_POST['points'] ?? 1;
$created_by = $_SESSION['teacher_id'];
$image_url = null;

// Handle file upload if present
if (!empty($_FILES['image']['name'])) {
    $targetDir = "../assets/images/";
    
    // Create directory if it doesn't exist
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }
    
    $fileName = basename($_FILES["image"]["name"]);
    $targetFilePath = $targetDir . time() . "_" . $fileName;
    
    // Check file type (optional security measure)
    $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
    $allowedTypes = array('jpg', 'jpeg', 'png', 'gif');
    
    if (in_array($fileType, $allowedTypes)) {
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFilePath)) {
            $image_url = str_replace("../", "", $targetFilePath);
        } else {
            header("Location: add_question.php?error=upload_failed");
            exit();
        }
    } else {
        header("Location: add_question.php?error=invalid_file_type");
        exit();
    }
}

try {
    $stmt = $pdo->prepare("INSERT INTO questions (category_id, question_text, image_url, points, created_by) VALUES (?, ?, ?, ?, ?)");
    $result = $stmt->execute([$category_id, $question_text, $image_url, $points, $created_by]);
    
    if ($result) {
        header("Location: add_question.php?success=1");
        exit();
    } else {
        header("Location: add_question.php?error=db_error");
        exit();
    }
} catch (PDOException $e) {
    header("Location: add_question.php?error=db_error");
    exit();
}
?>