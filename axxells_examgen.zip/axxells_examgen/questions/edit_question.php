<?php
session_start();
require_once("../config/db.php");

if (!isset($_SESSION['teacher_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$teacher_id = $_SESSION['teacher_id'];
$school_id = $_SESSION['school_id'];
$question_id = $_GET['id'] ?? 0;
$success = isset($_GET['success']) ? true : false;
$error = isset($_GET['error']) ? $_GET['error'] : '';

// Fetch the question data
$stmt = $pdo->prepare("SELECT * FROM questions WHERE question_id = ?");
$stmt->execute([$question_id]);
$question = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$question) {
    header("Location: view_questions.php?error=not_found");
    exit();
}

// Get courses for this school
$stmt_courses = $pdo->prepare("SELECT * FROM courses WHERE school_id = ? OR school_id IS NULL");
$stmt_courses->execute([$school_id]);
$courses = $stmt_courses->fetchAll(PDO::FETCH_ASSOC);

// Get categories for the course
$stmt_categories = $pdo->prepare("SELECT c.* FROM categories c 
                                 JOIN questions q ON c.category_id = q.category_id 
                                 WHERE q.question_id = ?");
$stmt_categories->execute([$question_id]);
$current_category = $stmt_categories->fetch(PDO::FETCH_ASSOC);

if ($current_category) {
    $stmt_all_categories = $pdo->prepare("SELECT * FROM categories WHERE course_id = ? ORDER BY category_name");
    $stmt_all_categories->execute([$current_category['course_id']]);
    $categories = $stmt_all_categories->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Question - Axxells Examgen</title>
    <meta charset="UTF-8">
    <script src="https://cdn.tiny.cloud/1/5g9cz15ehmlfl5etflwckxuo4tqe7hmpo5mqg1lsl0chgf53/tinymce/7/tinymce.min.js" referrerpolicy="origin"></script>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
        h2 { color: #333; }
        .message { padding: 10px; margin-bottom: 15px; border-radius: 4px; }
        .success { background-color: #d4edda; color: #155724; }
        .error { background-color: #f8d7da; color: #721c24; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        select, input[type="number"], input[type="file"] { width: 100%; padding: 8px; margin-bottom: 15px; box-sizing: border-box; }
        button { background-color: #4CAF50; color: white; padding: 10px 15px; border: none; cursor: pointer; }
        button:hover { background-color: #45a049; }
        .nav-links { margin-top: 20px; }
        .nav-links a { margin-right: 15px; }
        .current-image { margin: 15px 0; max-width: 100%; }
        .current-image img { max-width: 300px; border: 1px solid #ddd; padding: 5px; }
    </style>
    <script>
    tinymce.init({
        selector: '#question_text',
        height: 300,
        plugins: [
            'anchor', 'autolink', 'charmap', 'codesample', 'emoticons', 'image', 'link', 'lists', 'media', 'searchreplace', 'table', 'visualblocks', 'wordcount',
            'checklist', 'mediaembed', 'casechange', 'formatpainter', 'pageembed', 'advtable', 'advcode', 'mathjax'
        ],
        toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table | mathjax | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat',
        mathjax: {
            lib: 'https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js'
        }
    });
    </script>
</head>
<body>
    <h2>Edit Question</h2>
    
    <?php if ($success): ?>
        <div class="message success">Question updated successfully!</div>
    <?php endif; ?>
    
    <?php if (!empty($error)): ?>
        <div class="message error">
            <?php 
                switch($error) {
                    case 'missing_fields':
                        echo "Please fill in all required fields.";
                        break;
                    case 'upload_failed':
                        echo "Image upload failed.";
                        break;
                    case 'invalid_file_type':
                        echo "Invalid file type. Please upload JPG, JPEG, PNG or GIF.";
                        break;
                    case 'db_error':
                        echo "Database error occurred. Please try again.";
                        break;
                    default:
                        echo "An error occurred. Please try again.";
                }
            ?>
        </div>
    <?php endif; ?>
    
    <form method="post" action="update_question.php" enctype="multipart/form-data">
        <input type="hidden" name="question_id" value="<?= $question_id ?>">
        
        <label for="course_id">Select Course:</label>
        <select name="course_id" id="course_id" required onchange="fetchCategories(this.value)">
            <option value="">-- Select Course --</option>
            <?php foreach ($courses as $course): ?>
                <option value="<?= $course['course_id'] ?>" <?= ($current_category && $current_category['course_id'] == $course['course_id']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($course['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="category_id">Select Category:</label>
        <select name="category_id" id="category_select" required>
            <option value="">-- Select Category --</option>
            <?php if (isset($categories)): ?>
                <?php foreach ($categories as $category): ?>
                    <option value="<?= $category['category_id'] ?>" <?= ($question['category_id'] == $category['category_id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($category['category_name']) ?>
                    </option>
                <?php endforeach; ?>
            <?php endif; ?>
        </select>

        <label for="question_text">Question:</label>
        <textarea id="question_text" name="question_text"><?= htmlspecialchars($question['question_text']) ?></textarea>

        <?php if (!empty($question['image_url'])): ?>
            <div class="current-image">
                <p>Current Image:</p>
                <img src="../<?= htmlspecialchars($question['image_url']) ?>" alt="Question Image">
                <label>
                    <input type="checkbox" name="delete_image" value="1"> Delete current image
                </label>
            </div>
        <?php endif; ?>

        <label for="image">Image (optional, leave empty to keep current):</label>
        <input type="file" name="image" id="image">

        <label for="points">Points:</label>
        <input type="number" name="points" id="points" value="<?= $question['points'] ?>" min="1" required>

        <button type="submit">Update Question</button>
    </form>
    
    <div class="nav-links">
        <a href="view_questions.php">Back to Questions</a>
        <a href="../dashboard/index.php">Back to Dashboard</a>
    </div>

    <script>
    function fetchCategories(courseId) {
        if (!courseId) return;
        
        fetch('get_categories.php?course_id=' + courseId)
            .then(response => response.json())
            .then(data => {
                let categorySelect = document.getElementById('category_select');
                categorySelect.innerHTML = '<option value="">-- Select Category --</option>';
                
                if (data.error) {
                    console.error(data.error);
                    return;
                }
                
                data.forEach(category => {
                    const selected = category.category_id == <?= json_encode($question['category_id']) ?> ? 'selected' : '';
                    categorySelect.innerHTML += `<option value="${category.category_id}" ${selected}>${category.category_name || 'Unnamed Category'}</option>`;
                });
            })
            .catch(error => console.error('Error fetching categories:', error));
    }
    </script>
</body>
</html>