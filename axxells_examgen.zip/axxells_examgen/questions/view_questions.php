<?php
require_once("../config/db.php");
session_start(); // Make sure session is started

// Check if user is logged in as a teacher
if (!isset($_SESSION['teacher_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

// Initialize message variable
$message = '';
$message_type = '';

// Handle success or error messages from redirects
if (isset($_GET['success'])) {
    if ($_GET['success'] === 'deleted') {
        $message = "Frågan har tagits bort framgångsrikt!";
        $message_type = 'success';
    }
}

if (isset($_GET['error'])) {
    $message_type = 'error';
    switch ($_GET['error']) {
        case 'invalid_id':
            $message = "Ogiltigt fråge-ID.";
            break;
        case 'not_found':
            $message = "Frågan hittades inte.";
            break;
        case 'unauthorized':
            $message = "Du har inte behörighet att ta bort denna fråga.";
            break;
        case 'delete_failed':
            $message = "Borttagning av frågan misslyckades.";
            break;
        case 'db_error':
            $message = "Ett databasfel uppstod: ";
            if (isset($_GET['details'])) {
                $message .= htmlspecialchars($_GET['details']);
            }
            break;
        default:
            $message = "Ett fel uppstod.";
    }
}

// Handle POST request for update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $question_id = $_POST['question_id'];
    $question_text = $_POST['question_text'];
    $category_id = $_POST['category_id'];
    $points = isset($_POST['points']) ? $_POST['points'] : 1; // Default is 1 if not specified
    $created_by = $_SESSION['teacher_id'];

    try {
        // First check if the question exists
        $check_stmt = $pdo->prepare("SELECT * FROM questions WHERE question_id = ?");
        $check_stmt->execute([$question_id]);
        
        if ($check_stmt->rowCount() > 0 && !empty($question_id)) {
            // Update existing question
            $stmt = $pdo->prepare("UPDATE questions SET question_text = ?, category_id = ?, points = ? WHERE question_id = ?");
            $stmt->execute([$question_text, $category_id, $points, $question_id]);
            $message = "Frågan har uppdaterats framgångsrikt!";
            $message_type = 'success';
        } else {
            // Add a new question if it doesn't exist
            $stmt = $pdo->prepare("INSERT INTO questions (question_text, category_id, points, created_by) VALUES (?, ?, ?, ?)");
            $stmt->execute([$question_text, $category_id, $points, $created_by]);
            $message = "En ny fråga har lagts till framgångsrikt!";
            $message_type = 'success';
        }
    } catch (PDOException $e) {
        $message = "Ett fel uppstod vid sparande av frågan: " . $e->getMessage();
        $message_type = 'error';
    }
}

try {
    // Fetch all questions for display
    $stmt_questions = $pdo->query("
        SELECT q.*, c.category_name, co.name as course_name, co.course_id
        FROM questions q
        LEFT JOIN categories c ON q.category_id = c.category_id
        LEFT JOIN courses co ON c.course_id = co.course_id
        ORDER BY q.question_id DESC
    ");
    $questions = $stmt_questions->fetchAll(PDO::FETCH_ASSOC);

    // Fetch categories and courses
    $stmt_categories = $pdo->query("SELECT * FROM categories");
    $categories = $stmt_categories->fetchAll(PDO::FETCH_ASSOC);

    $stmt_courses = $pdo->query("SELECT * FROM courses");
    $courses = $stmt_courses->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $message = "Ett fel uppstod vid hämtning av data: " . $e->getMessage();
    $message_type = 'error';
    
    // Initialize empty arrays in case of error
    $questions = [];
    $categories = [];
    $courses = [];
}

// Create an array to store categories by course
$categoriesByCourse = [];
foreach ($categories as $category) {
    if (!isset($categoriesByCourse[$category['course_id']])) {
        $categoriesByCourse[$category['course_id']] = [];
    }
    $categoriesByCourse[$category['course_id']][] = $category;
}
?>

<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <title>Hantera frågor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        table { 
            border-collapse: collapse; 
            width: 100%; 
            margin-top: 20px;
        }
        th, td { 
            border: 1px solid #ddd; 
            padding: 8px; 
            text-align: left; 
        }
        th { 
            background-color: #f2f2f2; 
        }
        tr:nth-child(even) { 
            background-color: #f9f9f9; 
        }
        .success { 
            color: green; 
            font-weight: bold;
            margin: 10px 0;
            padding: 10px;
            background-color: #d4edda;
            border-radius: 4px;
        }
        .error { 
            color: #721c24; 
            font-weight: bold;
            margin: 10px 0;
            padding: 10px;
            background-color: #f8d7da;
            border-radius: 4px;
        }
        form {
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin: 10px 0 5px;
            font-weight: bold;
        }
        input[type="text"], select, textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            margin-bottom: 10px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .action-button {
            background-color: #2196F3;
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 5px;
        }
        .action-button:hover {
            background-color: #0b7dda;
        }
        .delete-button {
            background-color: #f44336;
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .delete-button:hover {
            background-color: #d32f2f;
        }
        .confirmation-dialog {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            z-index: 1000;
        }
        .confirmation-content {
            background-color: white;
            margin: 15% auto;
            padding: 20px;
            width: 50%;
            border-radius: 5px;
            text-align: center;
        }
        .confirmation-buttons {
            margin-top: 20px;
        }
        .confirmation-buttons button {
            margin: 0 10px;
            padding: 8px 16px;
        }
        .cancel-button {
            background-color: #ccc;
            color: black;
        }
        .confirm-button {
            background-color: #f44336;
        }
        .debug-info {
            background-color: #f0f0f0;
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
            font-family: monospace;
        }
    </style>
</head>
<body>
    <h2>Hantera frågor</h2>
    
    <?php if (!empty($message)): ?>
        <p class="<?= $message_type ?>"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>
    
    <h3>Lägg till/redigera fråga</h3>
    <form method="POST">
        <label for="question_id">Fråge-ID (lämna tomt för att lägga till ny):</label>
        <input type="text" name="question_id" id="question_id">

        <label for="question_text">Frågetext:</label>
        <textarea name="question_text" id="question_text" rows="4" required></textarea>

        <label for="points">Poäng:</label>
        <input type="number" name="points" id="points" value="1" min="1" required>

        <label for="course_id">Välj kurs:</label>
        <select name="course_id" id="course_id" onchange="updateCategories()" required>
            <option value="">-- Välj kurs --</option>
            <?php foreach ($courses as $course): ?>
                <option value="<?= $course['course_id'] ?>"><?= htmlspecialchars($course['name']) ?></option>
            <?php endforeach; ?>
        </select>

        <label for="category_id">Välj kategori:</label>
        <select name="category_id" id="category_id" required>
            <option value="">-- Välj kategori --</option>
            <?php foreach ($categories as $category): ?>
                <option value="<?= $category['category_id'] ?>" data-course="<?= $category['course_id'] ?>" style="display:none;"><?= htmlspecialchars($category['category_name']) ?></option>
            <?php endforeach; ?>
        </select>

        <label for="question_type">Frågetyp (endast för visning):</label>
        <select name="question_type_display" id="question_type_display">
            <option value="text">Text</option>
            <option value="multiple">Flervalsfråga</option>
            <option value="truefalse">Sant/Falskt</option>
            <option value="multiplechoice">Flerval</option>
        </select>

        <button type="submit">Spara</button>
    </form>

    <h3>Frågelista</h3>
    <?php if (empty($questions)): ?>
        <p>Inga frågor hittades. Lägg till din första fråga ovan.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Fråge-ID</th>
                    <th>Frågetext</th>
                    <th>Kategori</th>
                    <th>Kurs</th>
                    <th>Poäng</th>
                    <th>Åtgärder</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($questions as $question): ?>
                    <tr>
                        <td><?= htmlspecialchars($question['question_id']) ?></td>
                        <td><?= htmlspecialchars(strip_tags($question['question_text'])) ?></td>
                        <td><?= htmlspecialchars($question['category_name'] ?? 'Okänd') ?></td>
                        <td><?= htmlspecialchars($question['course_name'] ?? 'Okänd') ?></td>
                        <td><?= htmlspecialchars($question['points']) ?></td>
                        <td>
                            <button class="action-button" onclick="fillForm(
                                '<?= $question['question_id'] ?>',
                                '<?= htmlspecialchars(str_replace(array("\r", "\n"), '', addslashes($question['question_text'])), ENT_QUOTES) ?>',
                                '<?= $question['category_id'] ?>',
                                '<?= $question['course_id'] ?>',
                                '<?= $question['points'] ?>'
                            )">Redigera</button>
                            <button class="delete-button" onclick="confirmDelete(<?= $question['question_id'] ?>)">Ta bort</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <!-- Confirmation Dialog -->
    <div id="deleteConfirmation" class="confirmation-dialog">
        <div class="confirmation-content">
            <h3>Bekräfta borttagning</h3>
            <p>Är du säker på att du vill ta bort denna fråga? Denna åtgärd kan inte ångras.</p>
            <div class="confirmation-buttons">
                <button class="cancel-button" onclick="closeConfirmation()">Avbryt</button>
                <button id="confirmDeleteBtn" class="confirm-button">Ta bort</button>
            </div>
        </div>
    </div>

    <!-- Debug information (only visible in development) -->
    <?php if (defined('DEBUG') && DEBUG): ?>
    <div class="debug-info">
        <h3>Debug Information</h3>
        <p>Database connection: <?= $pdo ? 'Success' : 'Failed' ?></p>
        <p>Questions count: <?= count($questions) ?></p>
        <p>Categories count: <?= count($categories) ?></p>
        <p>Courses count: <?= count($courses) ?></p>
    </div>
    <?php endif; ?>

    <script>
        // Function to update categories based on selected course
        function updateCategories() {
            const courseSelect = document.getElementById('course_id');
            const categorySelect = document.getElementById('category_id');
            const selectedCourse = courseSelect.value;
            
            // Hide all category options
            for (let i = 0; i < categorySelect.options.length; i++) {
                categorySelect.options[i].style.display = 'none';
            }
            
            // Show only categories for the selected course
            for (let i = 0; i < categorySelect.options.length; i++) {
                if (categorySelect.options[i].dataset.course === selectedCourse || categorySelect.options[i].value === '') {
                    categorySelect.options[i].style.display = '';
                }
            }
            
            // Reset category selection
            categorySelect.value = '';
        }

        // Function to fill the form with existing question data
        function fillForm(id, text, category, course, points) {
            document.getElementById('question_id').value = id;
            document.getElementById('question_text').value = text.replace(/\\'/g, "'");
            document.getElementById('course_id').value = course;
            updateCategories(); // Update category options
            setTimeout(() => {
                document.getElementById('category_id').value = category;
            }, 100); // Small delay to ensure categories are updated first
            document.getElementById('points').value = points;
        }

        // Function to show delete confirmation dialog
        function confirmDelete(questionId) {
            const confirmDialog = document.getElementById('deleteConfirmation');
            const confirmBtn = document.getElementById('confirmDeleteBtn');
            
            confirmDialog.style.display = 'block';
            confirmBtn.onclick = function() {
                window.location.href = 'delete_question.php?id=' + questionId;
            };
        }

        // Function to close confirmation dialog
        function closeConfirmation() {
            document.getElementById('deleteConfirmation').style.display = 'none';
        }

        // Initialize categories on page load
        document.addEventListener('DOMContentLoaded', function() {
            updateCategories();
        });

        // Close confirmation dialog if user clicks outside of it
        window.onclick = function(event) {
            const confirmDialog = document.getElementById('deleteConfirmation');
            if (event.target === confirmDialog) {
                confirmDialog.style.display = 'none';
            }
        };
    </script>
    <div class="nav-links">
        <a href="../dashboard/index.php">Back to Dashboard</a>
    </div>
</body>
</html>