<?php 
require_once("../config/db.php");
session_start();

if (!isset($_SESSION['teacher_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Not authenticated']);
    exit();
}

if (isset($_GET['course_id']) && is_numeric($_GET['course_id'])) {
    $course_id = intval($_GET['course_id']);
    
    $stmt = $pdo->prepare("SELECT * FROM categories WHERE course_id = ? ORDER BY category_name");
    $stmt->execute([$course_id]);
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    header('Content-Type: application/json');
    echo json_encode($categories);
    exit();
} else {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Invalid course ID']);
    exit();
}
?>