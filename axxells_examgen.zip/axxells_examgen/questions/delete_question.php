<?php
session_start();
require_once("../config/db.php");

// Kontrollera om läraren är inloggad
if (!isset($_SESSION['teacher_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

// Kontrollera om frågans ID är angivet
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: view_questions.php?error=ogiltigt_id");
    exit();
}

$question_id = intval($_GET['id']);
$teacher_id = $_SESSION['teacher_id'];

try {
    // Starta transaktionen
    $pdo->beginTransaction();
    
    // Kontrollera först om frågan finns
    $check_stmt = $pdo->prepare("SELECT question_id FROM questions WHERE question_id = ?");
    $check_stmt->execute([$question_id]);
    
    if ($check_stmt->rowCount() == 0) {
        // Frågan finns inte
        $pdo->rollBack();
        header("Location: view_questions.php?error=inte_hittad");
        exit();
    }
    
    // Ta bort alla referenser i test_questions först
    $delete_refs_stmt = $pdo->prepare("DELETE FROM test_questions WHERE question_id = ?");
    $delete_refs_stmt->execute([$question_id]);
    
    // Nu ta bort själva frågan
    $stmt = $pdo->prepare("DELETE FROM questions WHERE question_id = ?");
    $stmt->execute([$question_id]);
    
    // Kontrollera om borttagningen var framgångsrik
    if ($stmt->rowCount() > 0) {
        $pdo->commit();
        header("Location: view_questions.php?success=borttagen");
        exit();
    } else {
        $pdo->rollBack();
        header("Location: view_questions.php?error=borttagning_misslyckades");
        exit();
    }
    
} catch (PDOException $e) {
    // Ångra transaktionen vid fel
    $pdo->rollBack();
    
    // Omdirigera med felmeddelande
    header("Location: view_questions.php?error=databasfel&details=" . urlencode($e->getMessage()));
    exit();
}
?>