<?php
session_start();
require_once("../config/db.php");

if (!isset($_SESSION['teacher_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$teacher_id = $_SESSION['teacher_id'];
$school_id = $_SESSION['school_id'];

// Hämta meddelanden
$success = isset($_GET['success']) ? true : false;
$error = isset($_GET['error']) ? $_GET['error'] : '';

// Hämta kurser för skolan
$stmt_courses = $pdo->prepare("SELECT * FROM courses WHERE school_id = ? OR school_id IS NULL");
$stmt_courses->execute([$school_id]);
$courses = $stmt_courses->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <title>Lägg till Fråga - Axxells Examgen</title>
    <script src="https://cdn.tiny.cloud/1/5g9cz15ehmlfl5etflwckxuo4tqe7hmpo5mqg1lsl0chgf53/tinymce/7/tinymce.min.js" referrerpolicy="origin"></script>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
        h2 { color: #333; }
        .message { padding: 10px; margin-bottom: 15px; border-radius: 4px; }
        .success { background-color: #d4edda; color: #155724; }
        .error { background-color: #f8d7da; color: #721c24; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        select, input[type="number"], input[type="file"] { width: 100%; padding: 8px; margin-bottom: 15px; box-sizing: border-box; }
        button { background-color: #4CAF50; color: white; padding: 10px 15px; border: none; cursor: pointer; }
        button:hover { background-color: #45a049; }
        .nav-links { margin-top: 20px; }
        .nav-links a { margin-right: 15px; }
    </style>
    <script>
    tinymce.init({
        selector: '#question_text',
        height: 300,
        plugins: [
            'anchor', 'autolink', 'charmap', 'codesample', 'emoticons', 'image', 'link', 'lists', 'media', 'searchreplace', 'table', 'visualblocks', 'wordcount',
            'checklist', 'mediaembed', 'casechange', 'formatpainter', 'pageembed', 'advtable', 'advcode', 'mathjax'
        ],
        toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table | mathjax | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat',
        mathjax: {
            lib: 'https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js'
        }
    });
    </script>
</head>
<body>
    <h2>Lägg till ny fråga</h2>
    
    <?php if ($success): ?>
        <div class="message success">Frågan har lagts till!</div>
    <?php endif; ?>
    
    <?php if (!empty($error)): ?>
        <div class="message error">
            <?php 
                switch($error) {
                    case 'missing_fields':
                        echo "Vänligen fyll i alla obligatoriska fält.";
                        break;
                    case 'upload_failed':
                        echo "Bilduppladdningen misslyckades.";
                        break;
                    case 'invalid_file_type':
                        echo "Ogiltig filtyp. Vänligen ladda upp JPG, JPEG, PNG eller GIF.";
                        break;
                    case 'db_error':
                        echo "Ett databasfel uppstod. Försök igen.";
                        break;
                    default:
                        echo "Ett fel uppstod. Försök igen.";
                }
            ?>
        </div>
    <?php endif; ?>
    
    <form method="post" action="save_question.php" enctype="multipart/form-data">
        <label for="course_id">Välj kurs:</label>
        <select name="course_id" id="course_id" required onchange="fetchCategories(this.value)">
            <option value="">-- Välj kurs --</option>
            <?php foreach ($courses as $course): ?>
                <option value="<?= $course['course_id'] ?>"><?= htmlspecialchars($course['name']) ?></option>
            <?php endforeach; ?>
        </select>

        <label for="category_id">Välj kategori:</label>
        <select name="category_id" id="category_select" required>
            <option value="">-- Välj kategori --</option>
            <!-- Fylls i via JavaScript -->
        </select>

        <label for="question_text">Fråga:</label>
        <textarea id="question_text" name="question_text"></textarea>

        

        <label for="points">Poäng:</label>
        <input type="number" name="points" id="points" value="1" min="1" required>

        <button type="submit">Spara fråga</button>
    </form>
    
    <div class="nav-links">
        <a href="../dashboard/index.php">← Tillbaka till instrumentpanelen</a>
    </div>

    <script>
    function fetchCategories(courseId) {
        if (!courseId) return;
        
        fetch('get_categories.php?course_id=' + courseId)
            .then(response => response.json())
            .then(data => {
                let categorySelect = document.getElementById('category_select');
                categorySelect.innerHTML = '<option value="">-- Välj kategori --</option>';
                
                if (data.error) {
                    console.error(data.error);
                    return;
                }
                
                data.forEach(category => {
                    categorySelect.innerHTML += `<option value="${category.category_id}">${category.category_name || 'Namnlös kategori'}</option>`;
                });
            })
            .catch(error => console.error('Fel vid hämtning av kategorier:', error));
    }
    </script>
</body>
</html>